
class Sound {

    constructor() {}

    playMusic2D(path) {

        let audio = new Audio(path);
    
        if (localStorage.getItem('music-volume') != null) {
            audio.volume = localStorage.getItem('music-volume');
        } else {
            audio.volume = 0.03;
        }
    
        audio.loop = true;
    
        audio.play();
    }

    playSound2D(path) {

        let audio = new Audio(path);
    
        if (localStorage.getItem('sound-volume') != null) {
            audio.volume = localStorage.getItem('sound-volume');
        } else {
            audio.volume = 0.03;
        }
    
        audio.loop = false;
    
        audio.play();
    }

}

export { Sound };