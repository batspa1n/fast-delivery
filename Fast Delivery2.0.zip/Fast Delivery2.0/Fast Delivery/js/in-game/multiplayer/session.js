import { initializeApp } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js";
import { 
    getFirestore,  
    collection,
    doc, 
    query,
    where,
    onSnapshot, 
    getDoc,
    updateDoc,
    arrayRemove
} from "https://www.gstatic.com/firebasejs/9.18.0/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAXVGvvMaGlOgT8xvq10EZ0a2kSPpA1Cho",
    authDomain: "policias-vs-ratones.firebaseapp.com",
    projectId: "policias-vs-ratones",
    storageBucket: "policias-vs-ratones.appspot.com",
    messagingSenderId: "872110097470",
    appId: "1:872110097470:web:ef18ee3aef91342e203d6f"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const database = getFirestore(app);

const params = new URLSearchParams(window.location.search);
const sessionId = params.get('id');

if(sessionId == null || sessionId == undefined) {

    window.location.replace("/");
}

async function startGame() { 

    await updateDoc(doc(collection(database, "sessions", sessionId, "players"), localStorage.getItem('currentUserUid')), {
        start_game: true,
    });

}

// --- PLAYERS SNAPSHOT ---

let playersSnapshot = null;

function initPlayersSnapshot(callback) {
    
    const playersCollection = collection(database, "sessions", sessionId, "players");

    playersSnapshot = onSnapshot(playersCollection, (snapshot) => {

        callback(snapshot);
    
    });
}

function stopPlayersSnapshot() {

    playersSnapshot.unsub();
}



let enemyPlayerSnapshot = null;

function initEnemyPlayerSnapshot(callback) {
    
    const currentUserUid = localStorage.getItem("currentUserUid");

    const querySessions = query(collection(database, "sessions", sessionId, "players"), where("player_uid", "!=", currentUserUid));
    
    playersSnapshot = onSnapshot(querySessions, (snapshot) => {

        callback(snapshot);
    
    });
}

function stopEnemyPlayerSnapshot() {

    enemyPlayerSnapshot.unsub();
}

// --- END PLAYERS SNAPSHOT ---



// --- SESSION FUNCTIONS ---

function getSessionId() {
    return sessionId;
}

async function getSessionData() { 
    
    const sessionDocumentRef = doc(database, "sessions", sessionId);
    const sessionSnapshot = await getDoc(sessionDocumentRef);

    if (sessionSnapshot.exists()) {
        
        return sessionSnapshot.data();
    } else {
        
        return null;
    }
}

function initGameStateSnapshot(callback) {
    
    const sessionDoc = doc(database, "sessions", sessionId);

    onSnapshot(sessionDoc, (snapshot) => {

        callback(snapshot.data());
    
    });
}


// --- END SESSION FUNCTIONS ---



// --- PLAYER FUNCTIONS ---


let keyPressed = false;

let currentActionAnimation = "idle";

function setCurrentActionAnimation(action) {
    currentActionAnimation = action;
}

async function updateCurrentPlayer(positionX, positionZ, rotation, isInvulnerable) {

    if (!keyPressed) {

        keyPressed = true;

        setTimeout(async () => {
                    
            const currentUserUid = localStorage.getItem("currentUserUid");

            const currentPlayerDocument = doc(collection(database, "sessions", sessionId, "players"), currentUserUid);
        
            await updateDoc(currentPlayerDocument, {
                "position.x": positionX,
                "position.z": positionZ,
                "rotation": rotation,
                "action": currentActionAnimation,
                "is_invulnerable": isInvulnerable,
            });
        
            keyPressed = false;
        }, 100);
    }
 
}

async function removePowerUp(powerUpName) { 

    await updateDoc(doc(database, "sessions", sessionId), {

        power_ups: arrayRemove(powerUpName),
    });

}

async function spawnMouseTrap(positionX, positionZ) {

    await updateDoc(doc(database, "sessions", sessionId), {

        spawned_mouse_trap: {'positionX': positionX, 'positionZ': positionZ},
    });
}

async function destroyMouseTrap() {

    await updateDoc(doc(database, "sessions", sessionId), {

        spawned_mouse_trap: false,
    });
}

// --- END PLAYER FUNCTIONS ---

// --- PAUSE ---

async function setPause(pauseGame) {

    await updateDoc(doc(database, "sessions", sessionId), {

        game_paused: pauseGame,
    });
}

// --- END PAUSE -- 


// --- UPDATE OBJECTIVES ---

async function updateObjectives(count) { 

    const currentUserUid = localStorage.getItem("currentUserUid");

    const currentPlayerDocument = doc(collection(database, "sessions", sessionId, "players"), currentUserUid);

    await updateDoc(currentPlayerDocument, {
        "objectives_count": count,
    });
}


async function removeCheese(cheeseName) { 

    await updateDoc(doc(database, "sessions", sessionId), {

        cheeses: arrayRemove(cheeseName),
    });

}


function insertRecord(playerName, score) {

    $.ajax({
        type: "POST",
        url: "/services/InsertRecord.php",
        data: {
            player_name: playerName,
            score: score
        }
    }).done(function(data) {

    }).fail(function(e) {
        
    });
}


// --- END UPDATE OBJECTIVES ---



export { 
    getSessionId, 
    initGameStateSnapshot,
    initPlayersSnapshot, 
    stopPlayersSnapshot,
    setCurrentActionAnimation,
    initEnemyPlayerSnapshot,
    stopEnemyPlayerSnapshot,
    getSessionData,
    updateCurrentPlayer,
    removePowerUp,
    spawnMouseTrap,
    destroyMouseTrap,
    setPause,
    startGame,
    updateObjectives,
    removeCheese,
    insertRecord
}