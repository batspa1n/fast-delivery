import { initializeApp } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js";
import { 
    getFirestore,  
    collection,
    doc,
    query, 
    where, 
    getDocs,
    setDoc,
    updateDoc
} from "https://www.gstatic.com/firebasejs/9.18.0/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAXVGvvMaGlOgT8xvq10EZ0a2kSPpA1Cho",
    authDomain: "policias-vs-ratones.firebaseapp.com",
    projectId: "policias-vs-ratones",
    storageBucket: "policias-vs-ratones.appspot.com",
    messagingSenderId: "872110097470",
    appId: "1:872110097470:web:ef18ee3aef91342e203d6f"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const database = getFirestore(app);


document.addEventListener("DOMContentLoaded", async function() {
    
    const querySessions = query(collection(database, "sessions"), where("active", "==", true));

    const sessionDocuments = await getDocs(querySessions);

    sessionDocuments.forEach((session) => {

        const sessionData = session.data();

        $('#sessions-list').append(
            builSessionCard(session.id, sessionData['selected_character'], sessionData['map'], sessionData['difficulty'])
        );

    });


    $('.session-option').on('click', function(event) {

        const sessionId = $(this).data('session-id');
        const character = $(this).data('character');

        addPlayerToSession(sessionId, character);
    });


});


function builSessionCard(sessionId, selectedCharacter, map, difficulty) {

    const characterImage = (selectedCharacter == "mouse") ?
    `<img src="../assets/img/icons/policia-icon.png" alt="Mouse icon" width="40" class="me-3">` : 
    `<img src="../assets/img/icons/mouse-icon.png" alt="Mouse icon" width="60" class="me-3"></img>`;

    const availableCharacter =  (selectedCharacter == "mouse") ? "police_man" : "mouse";
    
    return `<div data-session-id="${sessionId}" data-character="${availableCharacter}" class="card-option session-option text-decoration-none full-centered-row w-75 mb-4 px-3 pt-3 pb-3">
                <div class="full-centered-column w-25">
                    ${characterImage}
                </div>
                <div class="w-75">
                    <span class="session-details">${map} | ${difficulty}</span>
                </div>
            </div>`;
}


async function addPlayerToSession(sessionId, character) {

    const currentUserUid = localStorage.getItem("currentUserUid");
    const currentPlayerName = localStorage.getItem("currentPlayerName");

    await updateDoc(doc(collection(database, "sessions"), sessionId), {
        active: false,
        player2_uid: currentUserUid
    });

    await setDoc(doc(collection(database, "sessions", sessionId, "players"), currentUserUid), {
        character: character,
        player_name: currentPlayerName,
        player_uid: currentUserUid,
        score: 0,
        action: "idle",
        position: {
            x: (character == 'mouse') ? 100.0 : -100.0,
            z: (character == 'mouse') ? 100.0 : -100.0,
        },
        rotation: 0,
        is_invulnerable: false,
        objectives_count: 0,
        start_game: false,
    });

    window.location.replace(`/multiplayer/lobby.html?id=${sessionId}`);
}