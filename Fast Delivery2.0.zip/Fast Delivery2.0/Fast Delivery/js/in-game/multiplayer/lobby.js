import { 
    getSessionId,
    initPlayersSnapshot,
    stopPlayersSnapshot,
    getSessionData
} from './session.js';


const sessionData = await getSessionData();

if(sessionData == null || sessionData == undefined) {

    window.location.replace("/");
}

initPlayersSnapshot((snapshot) => {

    let totalPlayers = 0;

    const playersListContainer = document.getElementById('players-list');
    playersListContainer.innerHTML = "";
        
    snapshot.forEach((player) => {

        const playerData = player.data();

        if(playerData['character'] == "police_man") {

            playersListContainer.innerHTML += loadPoliceManPlayer(playerData['player_name']);
        }

        if(playerData['character'] == "mouse") {

            playersListContainer.innerHTML += loadMousePlayer(playerData['player_name']);
        }

        totalPlayers++;

    });

    if(totalPlayers == 2) {

        const selectedMap = sessionData['map'];

        if(selectedMap == "cocina") {
            playersListContainer.innerHTML += `<a href="/multiplayer/kitchen.html?id=${getSessionId()}" draggable="false" class="button w-50"><span>EMPEZAR PARTIDA</span></a>`;
        }
        else if(selectedMap == "restaurante") {
            playersListContainer.innerHTML += `<a href="/multiplayer/restaurant.html?id=${getSessionId()}" draggable="false" class="button w-50"><span>EMPEZAR PARTIDA</span></a>`;
        }
        else {
            playersListContainer.innerHTML += `<a href="/multiplayer/parking.html?id=${getSessionId()}" draggable="false" class="button w-50"><span>EMPEZAR PARTIDA</span></a>`;
        }
       
    }

});



function loadMousePlayer(playerName) { 

    return `<div class="full-centered-row w-50 mb-4">
                <div class="full-centered-column w-25">
                    <img src="../assets/img/icons/mouse-icon.png" alt="Mouse icon" width="60" class="me-3">
                </div>
                <div class="w-75">
                    <span class="text-white player-name">${playerName}</span>
                </div>
            </div>`;
}


function loadPoliceManPlayer(playerName) {

    return `<div class="full-centered-row w-50 mb-4">
                <div class="full-centered-column w-25">
                    <img src="../assets/img/icons/policia-icon.png" alt="Mouse icon" width="40" class="me-3">
                </div>
                <div class="w-75">
                    <span class="text-white player-name">${playerName}</span>
                </div>
            </div>`;
}


window.addEventListener("unload", function(event) {

    stopPlayersSnapshot();
});