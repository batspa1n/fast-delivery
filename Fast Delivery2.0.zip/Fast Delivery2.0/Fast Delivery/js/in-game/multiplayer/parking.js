import * as THREE from '../../threejs/three.module.js';
import {MTLLoader} from '../../threejs/MTLLoader.js';
import {OBJLoader} from '../../threejs/OBJLoader.js';
import {FBXLoader} from '../../threejs/FBXLoader.js';
import {Character} from '../character.js';
import {PowerUp} from '../powerup.js';
import { Sound } from '../sound.js';
import { Cheese } from '../cheese.js';
import {
    getSessionData,
    initEnemyPlayerSnapshot,
    initGameStateSnapshot,
    updateCurrentPlayer,
    setCurrentActionAnimation,
    removePowerUp,
    spawnMouseTrap,
    destroyMouseTrap,
    setPause,
    updateObjectives,
    removeCheese,
    insertRecord,
} from './session.js';


// -- MUSIC --
const sound = new Sound();
sound.playMusic2D('/assets/sounds/gameplay.mp3');


// --- PAUSE ---

let gamePaused = false;
const pauseModal = new bootstrap.Modal(document.getElementById('pause-modal'));

const pauseButton = document.getElementById('pause-button');
pauseButton.addEventListener('click', function () { 

    setPause(true);
    pauseModal.show();

});

document.getElementById('play-button').addEventListener('click', function () { 
    
    setPause(false);
    pauseModal.hide();
});

// --- END PAUSE -- 

const sessionData = await getSessionData();

// -- MATCH --
const scoreMultiplier = sessionData['difficulty'] == 'fácil' ? 100 : 150;
const winnerModal = new bootstrap.Modal(document.getElementById('winner-modal'));
const winnerText = document.getElementById('winner-text');
const winnerName = document.getElementById('winner-name');
let gameFinished = false;

// -- SCENE --
const scene = new THREE.Scene();
new THREE.TextureLoader().load("/assets/img/backgrounds/fondo.png", function(texture) {

    scene.background = texture;
});


// -- CAMERA --
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight);
camera.position.set(0, 250, 0);
camera.rotateX(THREE.MathUtils.degToRad(-90.0));


// -- RENDERER --
const renderer = new THREE.WebGLRenderer({canvas: document.getElementById('game-canvas')});
renderer.setSize(window.innerWidth, window.innerHeight - 1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Opcional: especifica el tipo de sombra que deseas (opciones: BasicShadowMap, PCFShadowMap, PCFSoftShadowMap)
document.body.appendChild(renderer.domElement);

// Resize game
window.addEventListener("resize", function() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight - 1);
    renderer.render(scene, camera);
});

let loadedAssets = 0;
const totalAssets = 28;


// -- COLLISIONS --
const boundingBoxes = [];

function isCollidingWithScenario(character) {
  
    for (const boundingBox of boundingBoxes) {

        if (boundingBox.intersectsBox(character.boundingBox)) {

            return true;
        }
    }

    return false;
}

function isOutOfScenario(character) {
    
    const position = character.model.position;

    return (position.x < -130 || position.x > 130 ||
    position.z < -130 || position.z > 130);
}

function isCollidingWithEnemy(character) { 

    if(character.name == 'police-man' && character.boundingBox.intersectsBox(mouse.boundingBox) && !mouse.isInvulnerable) {
        
        character.objectivesCount++;

        const objectivesCount = document.getElementById('objectives-count');
        objectivesCount.textContent = character.objectivesCount;

        updateObjectives(character.objectivesCount);

        character.score += 1 * scoreMultiplier;

        const scoreText = document.getElementById('score');
        scoreText.textContent = character.score;

        if(character.objectivesCount >= 3) {

            policeMan.updateActionAnimation("celebrate");
            gameFinished = true;
            winnerText.textContent = '¡Has capturado al ratón!';
            winnerName.textContent = 'Has ganado la partida.';

            particles.visible = true;

            const currentPlayerName = localStorage.getItem("currentPlayerName");
            insertRecord(currentPlayerName, character.score);

            winnerModal.show();
        }

        mouse.model.position.x = 120.0;
        mouse.model.position.z = 120.0;
        
        policeMan.model.position.x = -120.0;
        policeMan.model.position.z = -120.0;

        // -- SOUND --
        sound.playSound2D('/assets/sounds/perder-vida.mp3');

        return;
    }

    if(character.name == 'mouse' && character.boundingBox.intersectsBox(policeMan.boundingBox) && !mouse.isInvulnerable) {
        
        policeMan.objectivesCount++;

        mouse.model.position.x = 120.0;
        mouse.model.position.z = 120.0;
        
        policeMan.model.position.x = -120.0;
        policeMan.model.position.z = -120.0;

        // -- SOUND --
        sound.playSound2D('/assets/sounds/perder-vida.mp3');
        
        return;
    }

}


// -- POWER UPS --

let powerUps = [];
let mouseTrap = null;
let mouseTrapModel = null;

function isCollidingWithPowerUp(character) { 

    powerUps.forEach((powerUp, index) => {

        if (powerUp.boundingBox.intersectsBox(character.boundingBox)) {

            if(powerUp.executePowerUp(character)) {

                if(powerUp.name != 'mouse-trap') {
                    
                    character.score += 1 * scoreMultiplier;
                    
                    const scoreText = document.getElementById('score');
                    scoreText.textContent = character.score;
                }

                if(powerUp.name == 'mouse-trap') {
                    destroyMouseTrap();
                }
                else {
                    removePowerUp(powerUp.name);
                }
                
                powerUps.splice(index, 1);
                scene.remove(powerUp.model);
            }

            return;
        }

    });

}

// -- CHEESES --

const cheeses = [];

function isCollidingWithCheeses() {

    cheeses.forEach((cheese, index) => {

        if(cheese.boundingBox.intersectsBox(mouse.boundingBox)) {

            mouse.objectivesCount++;

            const objectivesCount = document.getElementById('objectives-count');
            objectivesCount.textContent = mouse.objectivesCount;

            updateObjectives(mouse.objectivesCount);
            removeCheese(cheese.name);

            mouse.score += 1 * scoreMultiplier;

            const scoreText = document.getElementById('score');
            scoreText.textContent = mouse.score;
                
            sound.playSound2D('/assets/sounds/cheese-powerup.mp3');
    
            if(mouse.objectivesCount >= 3) {
    
                mouse.updateActionAnimation("celebrate");
                gameFinished = true;
                winnerText.textContent = '¡Has recolectado todos los quesos!';
                winnerName.textContent = 'Has ganado la partida.';

                particles.visible = true;

                const currentPlayerName = localStorage.getItem("currentPlayerName");
                insertRecord(currentPlayerName, mouse.score);
    
                winnerModal.show();
            }
    
            
            cheeses.splice(index, 1);
            scene.remove(cheese.model);
        }

        return;
    });

}

// -- PARTICLES --
let particles = null;

// -- CLOCK --
const clock = new THREE.Clock();


// -- CHARACTERS --
let currentPlayerCharacter = null;
let enemeyPlayerCharacter = null;
const mouse = new Character("mouse");
const policeMan = new Character("police-man");

// -- DIFFICULTY LIGHTS --

const difficultyLights = [];


// -- ASSETS LOADING FUNCTIONS --

function loadOBJWithMTL(path, objFile, mtlFile, onModelLoaded) {

    const mtlLoader = new MTLLoader();
    mtlLoader.setPath(path);

    // Load materials from MTL file
    mtlLoader.load(mtlFile, (materials) => {
    
        const objLoader = new OBJLoader();
        objLoader.setMaterials(materials)
        objLoader.setPath(path);
        objLoader.load(objFile, (model) => {

            onModelLoaded(model);
        });
    
    });

}

function loadMouseCharacter(isCurrentCharacter, initCurrentPlayerCharacter) {

    const fbxLoader = new FBXLoader();
    fbxLoader.setPath("/assets/models/characters/mouse/");

    fbxLoader.load('mouse_TposeSkeleton.fbx', (model) => {

        // Load animations
        mouse.model = model;
        mouse.mixer = new THREE.AnimationMixer(mouse.model)
    
        fbxLoader.load('mouse_idle.fbx', (asset) => {
            const idleAnimation = asset.animations[0];
            mouse.action.idle = mouse.mixer.clipAction(idleAnimation);
            mouse.action.idle.play();
            loadedAssets++;
        });

        fbxLoader.load('mouse_run.fbx',(asset) => {
            const runAnimation = asset.animations[0];
            mouse.action.run = mouse.mixer.clipAction(runAnimation);
            loadedAssets++;
        });

        fbxLoader.load('mouse_dance.fbx',(asset)=>{
            const celebreateAnimation = asset.animations[0];
            mouse.action.celebrate = mouse.mixer.clipAction(celebreateAnimation);
            loadedAssets++;
        });

        // Set properties
        model.name="mouse";
        model.position.x = 120.0;
        model.position.z = 120.0;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });
        
        scene.add(model);

        // Add bounding box
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        mouse.boundingBox = boundingBox;
        

        // Add spotlight if is selected character 
        if(isCurrentCharacter) {
            
            const spotLight = new THREE.SpotLight(0xffffff);
            spotLight.position.set(120, 15, 120);
            spotLight.intensity = 0.7;
            
            spotLight.target = model;
    
            mouse.light = spotLight;

            initCurrentPlayerCharacter(mouse);
        }


        mouse.loaded = true;
        loadedAssets++;
    });
}

function loadPoliceManCharacter(isCurrentCharacter, initCurrentPlayerCharacter) {

    const fbxLoader = new FBXLoader();
    fbxLoader.setPath("/assets/models/characters/police-man/");

    fbxLoader.load('police_TposeSkeleton.fbx', (model) => {

        // Load animations
        policeMan.model = model;
        policeMan.mixer = new THREE.AnimationMixer(policeMan.model)
    
        fbxLoader.load('police_idle.fbx', (asset) => {
            const idleAnimation = asset.animations[0];
            policeMan.action.idle = policeMan.mixer.clipAction(idleAnimation);
            policeMan.action.idle.play();
            loadedAssets++;
        });

        fbxLoader.load('police_running.fbx',(asset) => {
            const runAnimation = asset.animations[0];
            policeMan.action.run = policeMan.mixer.clipAction(runAnimation);
            loadedAssets++;
        });

        fbxLoader.load('police_dance.fbx',(asset)=>{
            const celebreateAnimation = asset.animations[0];
            policeMan.action.celebrate = policeMan.mixer.clipAction(celebreateAnimation);
            loadedAssets++;
        });

        // Set properties
        model.name="police-man";
        model.position.x = -120.0;
        model.position.z = -120.0;
        model.scale.set(0.08, 0.08, 0.08);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });
        
        scene.add(model);

        // Add bounding box
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        policeMan.boundingBox = boundingBox;

        
        // Add spotlight if is selected character 
        if(isCurrentCharacter) {
            
            const spotLight = new THREE.SpotLight(0xffffff);
            spotLight.position.set(-120, 15, -120);
            spotLight.intensity = 0.7;
            
            spotLight.target = model;
    
            policeMan.light = spotLight;

            initCurrentPlayerCharacter(policeMan);
        }

        policeMan.loaded = true;
        loadedAssets++;
    });
}



// -- GAME INITIALIZE --

function initGame() {
    
    initLights();
    initModels();
    initPowerUps();
    initCharacters();
    initCheeses();
    initParticles();

    initGameStateSnapshot((game) => {

        // -- UPDATE POWER UPS --
        let powerUpsObject = [] 

        powerUps.forEach((powerUp, index) => {

            if(!game['power_ups'].includes(powerUp.name)) {
                
                powerUpsObject.push({
                    object: powerUp,
                    index: index,
                });
            }

        });

        if(powerUpsObject.length > 0) {

            for (const powerUpObj of powerUpsObject) {

                if(powerUpObj.object != null && powerUpObj.index != null && powerUpObj.object.name != 'mouse-trap') {

                    if(powerUpObj.object.targetName == 'mouse') {
        
                        powerUpObj.object.executePowerUp(mouse, scene);
                    }
                    else {
        
                        powerUpObj.object.executePowerUp(policeMan, scene);
                    }
        
                    powerUps.splice(powerUpObj.index, 1);
                    scene.remove(powerUpObj.object.model);
                }
                
            }

        }
      

        // -- UPDATE MOUSE TRAP --
        if(game['spawned_mouse_trap'] != undefined && mouseTrap == null) {

          if(currentPlayerCharacter.name == "mouse") {
            loadOBJWithMTL("/assets/models/power-ups/mouse-trap/", "mousetrp.obj", "mousetrp.mtl", (model) => {
    
                mouseTrapModel = model;
                mouseTrapModel.position.x = game['spawned_mouse_trap'].positionX;
                mouseTrapModel.position.z = game['spawned_mouse_trap'].positionZ;
                mouseTrapModel.scale.set(0.2, 0.2, 0.2);
                mouseTrapModel.rotation.set(0, 0, 0);
    
                const newBoundingBox = new THREE.Box3();
                newBoundingBox.setFromObject(mouseTrapModel);
    
                mouseTrap = new PowerUp('mouse-trap', mouseTrapModel, 'mouse', newBoundingBox, 'trap', false);
                powerUps.push(mouseTrap);
    
                scene.add(mouseTrapModel);
            });
          }

        }
        else if(game['spawned_mouse_trap'] == false) {

            powerUps = powerUps.filter(item => item.name != 'mouse-trap');
            scene.remove(mouseTrapModel);

            mouseTrapModel = null;
        }


        // -- PAUSE GAME --
        if(game['game_paused'] == true) {
            
            gamePaused = true;
            pauseModal.show();
        }
        else {

            gamePaused = false;
            pauseModal.hide();
        }

        // -- UPDATE CHEESES --
        let deletedCheeses = [] 

        cheeses.forEach((cheese, index) => {

            if(!game['cheeses'].includes(cheese.name)) {
                
                deletedCheeses.push({
                    object: cheese,
                    index: index,
                });
            }

        });

        for (const cheese of deletedCheeses) {

            if(cheese.object != null && cheese.index != null) {

                cheeses.splice(cheese.index, 1);
                scene.remove(cheese.object.model);
            }
            
        }

    });
}


function initParticles() {

    const material = new THREE.PointsMaterial({
        size: 0.1,
        vertexColors: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        transparent: true
    });

    const geometry = new THREE.BufferGeometry();
    const positions = [];
    const colors = [];
    const numParticles = 500;

    for (let i = 0; i < numParticles; i++) {

        const position = new THREE.Vector3(
          Math.random() * 2 - 1,
          124.5,
          Math.random() * 2 - 1
        ).multiplyScalar(2);

        positions.push(position.x, position.y, position.z);

        const color = new THREE.Color();
        color.setRGB(Math.random(), Math.random(), Math.random());
        colors.push(color.r, color.g, color.b);
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    particles = new THREE.Points(geometry, material);

    particles.visible = false;

    scene.add(particles);
}


function initLights() {
    
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.1);
    scene.add(ambientLight);

    difficultyLights[0] = [];
    difficultyLights[1] = [];
    difficultyLights[2] = [];

    const pointLight1 = new THREE.PointLight(0xffffff, 2, 250);
    pointLight1.position.set(-120, 150, -120);
    pointLight1.name = '1';
    pointLight1.castShadow = true;
    scene.add(pointLight1);
    difficultyLights[0].push(pointLight1);

    const pointLight2 = new THREE.PointLight(0xffffff, 2, 250);
    pointLight2.position.set(-120, 150, 120);
    pointLight2.name = '2';
    pointLight2.castShadow = true;
    scene.add(pointLight2);
    difficultyLights[0].push(pointLight2);

    const pointLight3 = new THREE.PointLight(0xffffff, 0, 250);
    pointLight3.position.set(0, 150, -120);
    pointLight3.name = '3';
    pointLight3.castShadow = true;
    scene.add(pointLight3);
    difficultyLights[1].push(pointLight3);

    const pointLight4 = new THREE.PointLight(0xffffff, 0, 250);
    pointLight4.position.set(0, 150, 120);
    pointLight4.name = '4';
    pointLight4.castShadow = true;
    scene.add(pointLight4);
    difficultyLights[1].push(pointLight4);

    const pointLight5 = new THREE.PointLight(0xffffff, 0, 250);
    pointLight5.position.set(120, 150, -120);
    pointLight5.name = '5';
    pointLight5.castShadow = true;
    scene.add(pointLight5);
    difficultyLights[2].push(pointLight5);

    const pointLight6 = new THREE.PointLight(0xffffff, 0, 250);
    pointLight6.position.set(120, 150, 120);
    pointLight6.name = '6';
    pointLight6.castShadow = true;
    scene.add(pointLight6);
    difficultyLights[2].push(pointLight6);

    const lightsIntervalTime = sessionData['difficulty'] == 'fácil' ? 5000 : 15000;

    let lightIndex = 0;

    setInterval(() => {

        const prevIndex = lightIndex == 0 ? 2 : lightIndex - 1;

        for (const light of difficultyLights[prevIndex]) {

            
            light.intensity = 0;
        }

        for (const light of difficultyLights[lightIndex]) {

            
            light.intensity = 2.5;
        }

        lightIndex = (lightIndex + 1) == 3 ? 0 : lightIndex + 1;

    }, lightsIntervalTime);

}

function initModels() {

    // Piso del escenario

    // Se indica la carpeta donde se encuentra el OBJ y el MTL,
    // el archivo OBJ y el MTL. 
    // Al final se pasa una función que se ejecuta al cargar el modelo,
    // aquí se pueden modificar las propiedades del modelo y agregarlo a la escena
    loadOBJWithMTL("/assets/models/parking/floor/", "greenfloor.obj", "greenfloor.mtl", (model) => {
     
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.receiveShadow = true; // Permitir que el modelo reciba sombras
            }
          });
        scene.add(model);
        loadedAssets++;
    });

    //decoración del mapa

    loadOBJWithMTL("/assets/models/parking/floor/", "parking.obj", "parking.mtl", (model) => {
     
        // Transformación del modelo
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.receiveShadow = true; // Permitir que el modelo reciba sombras
            }
          });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/floor/", "restaurant.obj", "restaurant.mtl", (model) => {
     
        // Transformación del modelo
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });
          model.traverse(function(child) {
            if (child.isMesh) {
              child.receiveShadow = true; // Permitir que el modelo reciba sombras
            }
          });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/floor/", "colision.obj", "colision.mtl", (model) => {
     
        // Transformación del modelo
        model.scale.set(0.15, 0.15, 0.15);

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/floor/", "colision2.obj", "colision2.mtl", (model) => {
     
        // Transformación del modelo
        model.scale.set(0.15, 0.15, 0.15);

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/floor/", "colision3.obj", "colision3.mtl", (model) => {
     
        // Transformación del modelo
        model.scale.set(0.15, 0.15, 0.15);

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        scene.add(model);
        loadedAssets++;
    });

    //Objetos

    loadOBJWithMTL("/assets/models/parking/", "bags.obj", "bags.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = 110.0;
        model.position.z = 0.0;
        model.rotation.y = Math.PI/2;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "box1.obj", "box1.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = 20.0;
        model.position.z = 40.0;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "box2.obj", "box2.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = -90.0;
        model.position.z = -30.0;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "box3.obj", "box3.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = -120.0;
        model.position.z = -80.0;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "fridge.obj", "fridge.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = 80.0;
        model.position.z = 80.0;
        model.rotation.y = Math.PI;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "fridge2.obj", "fridge2.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = 100.0;
        model.position.z = 40.0;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "gas.obj", "gas.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = -30.0;
        model.position.z = 40.0;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "gas2.obj", "gas2.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = 120.0;
        model.position.z = -90.0;
        model.rotation.y = 3*Math.PI/4;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "shelving.obj", "shelving.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = -125.0;
        model.position.z = 30.0;
        model.rotation.y = Math.PI/2;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "trash.obj", "trash.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = -80.0;
        model.position.z = 60.0;
        model.rotation.y = Math.PI/2;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/parking/", "car.obj", "car.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = -16.0;
        model.position.z = 100.0;
        model.scale.set(0.15, 0.15, 0.15);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });
}


function initPowerUps() {

    loadOBJWithMTL("/assets/models/power-ups/donut/", "dona.obj", "dona.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = 60.0;
        model.position.z = 20.0;
        model.scale.set(2, 2, 2);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);

        const powerUp = new PowerUp('donut', model, 'police-man', boundingBox, 'speed');

        powerUps.push(powerUp);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/power-ups/cheese/", "cheese-flaminhot.obj", "cheese-flaminhot.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = 25.0;
        model.position.z = 90.0;
        model.scale.set(0.08, 0.08, 0.08);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);

        const powerUp = new PowerUp('cheese-flamin-hot', model, 'mouse', boundingBox, 'speed');

        powerUps.push(powerUp);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/power-ups/cheese/", "cheese-radioactive.obj", "cheese-radioactive.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = -60.0;
        model.position.z = 20.0;
        model.scale.set(0.08, 0.08, 0.08);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);

        const powerUp = new PowerUp('cheese-radiaoactive', model, 'mouse', boundingBox, 'invulnerable');

        powerUps.push(powerUp);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/power-ups/mouse-trap/", "mousetrp.obj", "mousetrp.mtl", (model) => {
     
        // Transformación del modelo
        model.position.x = 65.0;
        model.position.z = -110.0;
        model.scale.set(0.2, 0.2, 0.2);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);

        const powerUp = new PowerUp('trap', model, 'police-man', boundingBox, 'trap');

        powerUps.push(powerUp);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });
}


function initCharacters() {

    const currentCharacterIcon = document.getElementById('current-character-icon');
    const itemsIcon = document.getElementById('items-icon');
    const currentUserUid = localStorage.getItem('currentUserUid');

    initEnemyPlayerSnapshot((snapshot) => {
        
        snapshot.forEach((document) => {

            const characterData = document.data();

            if(characterData['character'] == "police_man") {
                
                if(!policeMan.loaded) {

                    loadPoliceManCharacter(false, function() {});
                    enemeyPlayerCharacter = policeMan;
                }
                else {

                    policeMan.updateActionAnimation(characterData['action']);
                    policeMan.model.position.x = characterData['position'].x;
                    policeMan.model.position.z = characterData['position'].z;
                    policeMan.model.rotation.y = characterData['rotation'];
                    policeMan.objectivesCount = characterData['objectives_count'];
                    policeMan.updateBoundingBox();

                    if(policeMan.objectivesCount >= 3) {

                        policeMan.updateActionAnimation("celebrate");
                        gameFinished = true;
                        winnerText.textContent = '¡Oh no, el policía finalmente te capturó!';
                        winnerName.textContent = 'Has perdido la partida.';

                        const currentPlayerName = localStorage.getItem("currentPlayerName");
                        insertRecord(currentPlayerName, mouse.score);
                        winnerModal.show();
                    }
            
                }

                if(!mouse.loaded) {
                    loadMouseCharacter(true, function(character) {

                        currentPlayerCharacter = character;
                        scene.add(currentPlayerCharacter.light);            
                    });

                    currentCharacterIcon.src = "../assets/img/icons/mouse-icon.png";
                    currentCharacterIcon.classList.remove('d-none');
                    currentCharacterIcon.classList.add('d-block');

                    itemsIcon.src = "../assets/img/icons/cheese.png";
                    itemsIcon.classList.remove('d-none');
                    itemsIcon.classList.add('d-block');
                }
                
                return;
            }
                    
            if(characterData['character'] == "mouse") {
            
                if(!mouse.loaded) {
                
                    loadMouseCharacter(false, function() {});
                    enemeyPlayerCharacter = mouse;
                }
                else {

                    mouse.updateActionAnimation(characterData['action']);
                    mouse.model.position.x = characterData['position'].x;
                    mouse.model.position.z = characterData['position'].z;
                    mouse.model.rotation.y = characterData['rotation'];
                    mouse.isInvulnerable = characterData['is_invulnerable'];
                    mouse.objectivesCount = characterData['objectives_count'];
                    mouse.updateBoundingBox();
                    

                    if(mouse.objectivesCount >= 3) {

                        gameFinished = true;
                        mouse.updateActionAnimation("celebrate");
                        winnerText.textContent = '¡Oh no, el ratón logró recolectar todos los quesos!';
                        winnerName.textContent = 'Has perdido la partida.';

                        const currentPlayerName = localStorage.getItem("currentPlayerName");
                        insertRecord(currentPlayerName, policeMan.score);

                        winnerModal.show();
                    }
                }

                if(!policeMan.loaded) {
                    loadPoliceManCharacter(true, function(character) {
                        
                        currentPlayerCharacter = character;
                        scene.add(currentPlayerCharacter.light);  
                    });

                    currentCharacterIcon.src = "../assets/img/icons/policia-icon.png";
                    currentCharacterIcon.classList.remove('d-none');
                    currentCharacterIcon.classList.add('d-block');

                    itemsIcon.src = "../assets/img/icons/mouse-icon.png";
                    itemsIcon.classList.remove('d-none');
                    itemsIcon.classList.add('d-block');
                }
            }

            if(currentUserUid == characterData['player_uid']) {

                currentPlayerCharacter.playerName = characterData['player_name'];
            }
            else {
                
                enemeyPlayerCharacter.playerName = characterData['player_name'];
            }
       
        });
    
    });

}


function initCheeses() {

    loadOBJWithMTL("/assets/models/power-ups/cheese/", "cheese.obj", "cheese.mtl", (model) => {

        // Transformación del modelo
        model.position.x = 130.0;
        model.position.z = -50.0;
        model.scale.set(0.08, 0.08, 0.08);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);

        const cheese = new Cheese('cheese1', model, boundingBox);
        cheeses.push(cheese);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/power-ups/cheese/", "cheese.obj", "cheese.mtl", (model) => {

        // Transformación del modelo
        model.position.x = -120.0;
        model.position.z = -30.0;
        model.scale.set(0.08, 0.08, 0.08);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);

        const cheese = new Cheese('cheese2', model, boundingBox);
        cheeses.push(cheese);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/assets/models/power-ups/cheese/", "cheese.obj", "cheese.mtl", (model) => {

        // Transformación del modelo
        model.position.x = -100.0;
        model.position.z = 100.0;
        model.scale.set(0.08, 0.08, 0.08);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.setFromObject(model);

        const cheese = new Cheese('cheese3', model, boundingBox);
        cheeses.push(cheese);

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

}


// -- CHARACTER MOVEMENT --

const inputActions = {
    up: "w",
    bottom: "s",
    left: "a",
    right: "d",
    interact: "e",
}

document.addEventListener("keydown", function (event) { 
    
    if(currentPlayerCharacter.canMove && !gamePaused && !gameFinished) {

        const pressedKey = event.key.toLowerCase();

        if(pressedKey == inputActions["up"]) {

            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {

            // currentPlayerCharacter.updatePositionZ(currentPlayerCharacter.model.position.z - 1);
                currentPlayerCharacter.model.position.z -= 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(180.0);
                setCurrentActionAnimation("run");
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
                
                updateCurrentPlayer(
                    currentPlayerCharacter.model.position.x, 
                    currentPlayerCharacter.model.position.z, 
                    currentPlayerCharacter.model.rotation.y,
                    currentPlayerCharacter.isInvulnerable,
                );
            
            }
            else {
                currentPlayerCharacter.model.position.z += 5;
            }

        
        }

        if(pressedKey == inputActions["bottom"]) {

            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {

                //currentPlayerCharacter.updatePositionZ(currentPlayerCharacter.model.position.z + 1);
                currentPlayerCharacter.model.position.z += 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(0.0);
                setCurrentActionAnimation("run");
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();

                updateCurrentPlayer(
                    currentPlayerCharacter.model.position.x, 
                    currentPlayerCharacter.model.position.z, 
                    currentPlayerCharacter.model.rotation.y,
                    currentPlayerCharacter.isInvulnerable,
                );
                
            }
            else {
                currentPlayerCharacter.model.position.z -= 5;
            }

        }

        if(pressedKey == inputActions["right"]) {

            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {

                //currentPlayerCharacter.updatePositionX(currentPlayerCharacter.model.position.x + 1);
                currentPlayerCharacter.model.position.x += 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(90.0);
                setCurrentActionAnimation("run");
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();

                updateCurrentPlayer(
                    currentPlayerCharacter.model.position.x, 
                    currentPlayerCharacter.model.position.z, 
                    currentPlayerCharacter.model.rotation.y,
                    currentPlayerCharacter.isInvulnerable,
                );
                
            }
            else {
                currentPlayerCharacter.model.position.x -= 5;
            }

        }

        if(pressedKey == inputActions["left"]) {

            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {

                currentPlayerCharacter.model.position.x -= 1 * currentPlayerCharacter.speedMultiplier;
            // currentPlayerCharacter.updatePositionX(currentPlayerCharacter.model.position.x - 1);
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(270.0);
                setCurrentActionAnimation("run");
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();

                updateCurrentPlayer(
                    currentPlayerCharacter.model.position.x, 
                    currentPlayerCharacter.model.position.z, 
                    currentPlayerCharacter.model.rotation.y,
                    currentPlayerCharacter.isInvulnerable,
                );
                
            }
            else {
                currentPlayerCharacter.model.position.x += 5;
            }

        }
        

        if(Object.values(inputActions).includes(pressedKey)) {
            
            isCollidingWithPowerUp(currentPlayerCharacter);

            isCollidingWithEnemy(currentPlayerCharacter);

            if(currentPlayerCharacter.name == 'mouse') {
    
                isCollidingWithCheeses();
            }
        }


        if(pressedKey == inputActions["interact"] && currentPlayerCharacter.name == 'police-man') {
            
            const trap = currentPlayerCharacter.setTrap();
            
            if(trap != null) {

                trap.boundingBox.setFromObject(trap.model);

                powerUps.push(trap);
                scene.add(trap.model);

                mouseTrapModel = trap.model;
                
                spawnMouseTrap(trap.model.position.x, trap.model.position.z);

                currentPlayerCharacter.trap = null;
            }
        }
    }

});


document.addEventListener("keyup", function (event) { 

    const unpressedKey = event.key.toLowerCase();

    const inputActionsValues = Object.values(inputActions);
    
    if (inputActionsValues.includes(unpressedKey)) { 
        
        currentPlayerCharacter.updateActionAnimation("idle");
        setCurrentActionAnimation("idle"); 

        updateCurrentPlayer(
            currentPlayerCharacter.model.position.x, 
            currentPlayerCharacter.model.position.z, 
            currentPlayerCharacter.model.rotation.y,
            currentPlayerCharacter.isInvulnerable,
        );
    }

});




// -- GAME START --

initGame();
animate();


function animate() {

    requestAnimationFrame(animate);

    
    if(loadedAssets >= totalAssets) {

        const delta = clock.getDelta();
        updateGame(delta);
        renderer.render(scene, camera);
    }
}


function updateGame(delta) {

    if(mouse.model != null) {
        mouse.mixer.update(delta);
        mouse.updateBoundingBox();
    }

    if(policeMan.model != null) {
        policeMan.mixer.update(delta);
        policeMan.updateBoundingBox();
    }

    for (const powerUp of powerUps) {
        powerUp.updateAnimation();
    }

    particles.rotation.y += 0.005;
} 
