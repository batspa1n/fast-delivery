
class PowerUp {

    constructor(name, model, targetName, boundingBox, type, animate = true) {
        
        this.name = name;
        this.model = model;
        this.targetName = targetName;
        this.boundingBox = boundingBox;
        this.type = type;
        this.animate = animate;
    }

    executePowerUp(character) {

        if(this.targetName == character.name && this.targetName == 'mouse') {
 
            if(this.type == 'speed') {

                character.speedMultiplier = 1.4;
    
                setTimeout(function() {
                    
                    character.speedMultiplier = 1;
                }, 5000);

                this.playPowerUpSound('/assets/sounds/cheese-powerup.mp3');
    
                return true;
            }

            if(this.type == 'invulnerable') {

                character.isInvulnerable = true;
    
                setTimeout(function() {
                    
                    character.isInvulnerable = false;
                }, 5000);

                this.playPowerUpSound('/assets/sounds/cheese-powerup.mp3');
    
                return true;
            }


            if(this.type == 'trap') {
                character.canMove = false;

                setTimeout(function() {
                    
                    character.canMove = true;
                }, 5000);

                this.playPowerUpSound('/assets/sounds/trap-powerup.mp3');
    
                return true;
            }
        }

        if(this.targetName == character.name && this.targetName == 'police-man') {

            if(this.type == 'speed') {

                character.speedMultiplier = 1.4;
    
                setTimeout(function() {
                    
                    character.speedMultiplier = 1;
                }, 5000);

                this.playPowerUpSound('/assets/sounds/donut-powerup.mp3');
    
                return true;
            }

            if(this.type == 'trap') {

                character.trap = this;

                this.playPowerUpSound('/assets/sounds/trap-powerup.mp3');

                return true;
            }
        }

        return false;
    }

    updateAnimation() {

        if(this.animate == true) {

            this.model.rotation.y += 0.01;
        }

    }

    playPowerUpSound(path) {
        
        let audio = new Audio(path);
        
        if (localStorage.getItem('sound-volume') != null) {
            audio.volume = localStorage.getItem('sound-volume');
        } else {
            audio.volume = 0.03;
        }
    
        audio.loop = false;
    
        audio.play();
    }

}

export { PowerUp };