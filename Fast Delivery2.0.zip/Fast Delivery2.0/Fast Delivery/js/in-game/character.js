
class Character {

    constructor(name) {
        this.loaded = false;
        this.name = name;
        this.winner =  false;
        this.lifes = 2;
        this.mixer = null;
        this.model = null;
        this.lastAction = "idle";
        this.boundingBox = null;
        this.action = {
            idle: null,
            run: null,
            celebrate: null
        }
        this.playerName = "";
        this.objectivesCount = 0;
        this.light = null;
        this.score = 0;

        // Power ups properties
        this.canMove = true;
        this.isInvulnerable = false;
        this.speedMultiplier = 1;
        this.trap = null;
    }

    updatePositionX(newPostionX) {

        const lastPositionX = this.model.position.x;
        this.model.position.x = newPostionX;

        if(newPostionX != lastPositionX) {
            this.updateActionAnimation("run");
        }
        else {
            this.updateActionAnimation("idle");
        }
    }

    updatePositionZ(newPositionZ) {

        const lastPositionZ = this.model.position.z;
        this.model.position.z = newPositionZ;

        if(newPositionZ != lastPositionZ) {
            this.updateActionAnimation("run");
        }
        else {
            this.updateActionAnimation("idle");
        }
    }

    updateActionAnimation(newAction)  {

        if(this.lastAction != newAction) {

            const lastAnimation = this.action[this.lastAction];
            const newAnimation = this.action[newAction];
    
            lastAnimation.reset();
            newAnimation.reset();
    
            const crossFadeTime = 0.2;
            lastAnimation.crossFadeTo(newAnimation, crossFadeTime).play();
            this.lastAction = newAction; 
        }
    }

    updateBoundingBox() {

        if(this.name == "mouse") {
            this.boundingBox.copy(this.model.children[0].boundingBox).applyMatrix4( this.model.matrixWorld );
        }
        else if(this.name == "police-man"){
            this.boundingBox.copy(this.model.children[0].children[0].children[1].boundingBox).applyMatrix4( this.model.matrixWorld );
        }

    }

    updateLightPosition() {

        this.light.position.x = this.model.position.x;
        this.light.position.z = this.model.position.z;
    }

    setTrap() {

        if(this.trap != null) {

            this.trap.name = 'mouse-trap';
            this.trap.targetName = 'mouse';
            this.trap.type = 'trap';
            this.trap.animate = false;

            this.trap.model.position.set(this.model.position.x, 0.0, this.model.position.z);
            this.trap.model.rotation.set(0.0, 0.0, 0.0);

            return this.trap;
        }

        return null;
    }

}

export { Character };