import * as THREE from '../../threejs/three.module.js';
import {MTLLoader} from '../../threejs/MTLLoader.js';
import {OBJLoader} from '../../threejs/OBJLoader.js';

document.body.setAttribute('data-canvas-state', 
    document.getElementById('game-canvas') ? 'Existe' : 'No existe');


// --- PAUSE ---
let gamePaused = false;
const pauseModal = new bootstrap.Modal(document.getElementById('pause-modal'));

const pauseButton = document.getElementById('pause-button');
pauseButton.addEventListener('click', function () { 
    gamePaused = true;
    pauseModal.show();

});

document.getElementById('play-button').addEventListener('click', function () { 
    gamePaused = false;
    pauseModal.hide();
});

// --- END PAUSE --

// -- MATCH --
const scoreMultiplier = localStorage.getItem('difficulty') == 'fácil' ? 100 : 150;
const winnerModal = new bootstrap.Modal(document.getElementById('winner-modal'));
const winnerText = document.getElementById('winner-text');
const winnerName = document.getElementById('winner-name');
let gameFinished = false;

// -- SCENE --
const scene = new THREE.Scene();
new THREE.TextureLoader().load("/Assets/img/Fondo_default.png", function(texture) {

    scene.background = texture;
});


// -- CAMERA --
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight);
camera.position.set(0, 250, 0);
camera.rotateX(THREE.MathUtils.degToRad(-90.0));

// -- RENDERER --
const renderer = new THREE.WebGLRenderer({canvas: document.getElementById('game-canvas')});
renderer.setSize(window.innerWidth, window.innerHeight - 1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Opcional: especifica el tipo de sombra que deseas (opciones: BasicShadowMap, PCFShadowMap, PCFSoftShadowMap)
document.body.appendChild(renderer.domElement);

// Resize game
window.addEventListener("resize", function() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight - 1);
    renderer.render(scene, camera);
});

let loadedAssets = 0;
const totalAssets = 31;


// -- COLLISIONS --
let boundingBoxes = [];
let floorBoundingBox = null;

function isCollidingWithScenario(character) {
  
    for (const boundingBox of boundingBoxes) {

        if (boundingBox.intersectsBox(character.boundingBox)) {

            return true;
        }
    }

    return false;
}

function isOutOfScenario(character) {
    
    const position = character.model.position;

    return (position.x < -130 || position.x > 130 ||
    position.z < -130 || position.z > 130);
}

// -- PARTICLES --
let particles = null;

// -- RAYCAST -- 
var rayCaster = new THREE.Raycaster();

// -- STATS --
const SPEED = 8;
const POLICE_RANGE = 10;

// -- CLOCK --
const clock = new THREE.Clock();

// -- DIFFICULTY LIGHTS --

const difficultyLights = [];

// -- OBJETOS CON COLISIÓN --
let objectsWithBoundingBox = [];

// -- SELECTED CHARACTER --
let singlePlayerSelectedCharacter = 'mouse';


// -- ASSETS LOADING FUNCTIONS --

function loadOBJWithMTL(path, objFile, mtlFile, onModelLoaded) {

    const mtlLoader = new MTLLoader();
    mtlLoader.setPath(path);

    // Load materials from MTL file
    mtlLoader.load(mtlFile, (materials) => {
    
        const objLoader = new OBJLoader();
        objLoader.setMaterials(materials)
        objLoader.setPath(path);
        objLoader.load(objFile, (model) => {

            onModelLoaded(model);
        });
    
    });

}

// -- GAME INITIALIZE --

function initGame() {
    
    initLights();
    initModels();
    initParticles();
}


function initParticles() {

    const material = new THREE.PointsMaterial({
        size: 0.1,
        vertexColors: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        transparent: true
      });

      const geometry = new THREE.BufferGeometry();
      const positions = [];
      const colors = [];
      const numParticles = 500;

      for (let i = 0; i < numParticles; i++) {

        const position = new THREE.Vector3(
          Math.random() * 2 - 1,
          124.5,
          Math.random() * 2 - 1
        ).multiplyScalar(2);

        positions.push(position.x, position.y, position.z);

        const color = new THREE.Color();
        color.setRGB(Math.random(), Math.random(), Math.random());
        colors.push(color.r, color.g, color.b);
      }

      geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

      particles = new THREE.Points(geometry, material);

      particles.visible = false;

      scene.add(particles);
}

function initLights() {
    // 1. LUZ AMBIENTAL PRINCIPAL - Más intensa y con tono cálido
    const ambientLight = new THREE.AmbientLight(0xfff4e6, 0.39); // Luz cálida, intensidad aumentada
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xFFFFFF, 0.5);
    directionalLight.position.set(50, 100, 50);
    directionalLight.castShadow = true; // Opcional: sombras dinámicas
    scene.add(directionalLight);

    const hemisphereLight = new THREE.HemisphereLight(0x87CEEB, 0x8B4513, 0.2);
    scene.add(hemisphereLight);


    // 6. CONFIGURACIONES DEL RENDERER PARA MEJOR ILUMINACIÓN
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.3;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.enabled = true;
}
function initModels() {

    // Piso del escenario

    // Se indica la carpeta donde se encuentra el OBJ y el MTL,
    // el archivo OBJ y el MTL. 
    // Al final se pasa una función que se ejecuta al cargar el modelo,
    // aquí se pueden modificar las propiedades del modelo y agregarlo a la escena
    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Pavimento.obj", "Pavimento.mtl", (model) => {
     
        model.scale.set(0.32, 0.10, 0.195);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.receiveShadow = true; // Permitir que el modelo genere sombras
            }
          });

        floorBoundingBox = new THREE.Box3();
        floorBoundingBox.setFromObject(model);

        scene.add(model);
        loadedAssets++;
    });

    //MODELOS
    //
    //Depa grises
    //
    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(-160, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(-125, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(-87, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(-52, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    //////////////////////////////////////////////////////////////////////////////
    ////Depas azules
    /////
    loadOBJWithMTL("/Assets/modelos/City/Edificio celeste ancho/", "Jubilife City Building.obj", "Jubilife City Building.mtl", (model) => {
     
        // Transformación del modelo   DER
        model.position.set(178, 0, 223);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio celeste alto/", "Jubilife City Building 2.obj", "Jubilife City Building 2.mtl", (model) => {
     
        // Transformación del modelo   DER
        model.position.set(178, 0, 213.5);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio celeste ancho/", "Jubilife City Building.obj", "Jubilife City Building.mtl", (model) => {
     
        // Transformación del modelo   DER
        model.position.set(250, 0, 223);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio celeste alto/", "Jubilife City Building 2.obj", "Jubilife City Building 2.mtl", (model) => {
     
        // Transformación del modelo   DER
        model.position.set(250, 0, 213.5);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    ////////////////////////////////////////////////////////////////////////////
    //Pisos
    //
    loadOBJWithMTL("/Assets/modelos/City/calles/", "Calle 1.obj", "Calle 1.mtl", (model) => {
        
        model.position.set(60, 0, 25);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/calles/", "Calle 3.obj", "Calle 3.mtl", (model) => {
        
        model.position.set(288, 0, -22.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/calles/", "Calle 4.obj", "Calle 4.mtl", (model) => {
        
        model.position.set(288, 0, -214.5);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/calles/", "Calle 1.obj", "Calle 1.mtl", (model) => {
        
        model.position.set(490, 0, 25);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/calles/", "Calle 2.obj", "Calle 2.mtl", (model) => {
        
        model.position.set(110, 0, -8.5);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/City/calles/", "Calle 2.obj", "Calle 2.mtl", (model) => {
        
        model.position.set(502, 0, -8.5);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //////Pasto
    loadOBJWithMTL("/Assets/modelos/City/calles/", "Pasto.obj", "Pasto.mtl", (model) => {
        
        model.position.set(200, 0, 114);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/calles/", "PPasto.obj", "PPasto.mtl", (model) => {
        
        model.position.set(200, 0, 114);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    ///////////////////////////////////////////////////////////////////////////////////////
    //Edificios Ilera izquierda
    //
    loadOBJWithMTL("/Assets/modelos/City/Edificio amarillo/", "Jubilife City Building 5.obj", "Jubilife City Building 5.mtl", (model) => {
     
        // Transformación del modelo
        model.position.set(-205, 0, 52.0);
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio amarillo/", "Jubilife City Building 5.obj", "Jubilife City Building 5.mtl", (model) => {
     
        // Transformación del modelo
        model.position.set(-178, 0, 52.0);
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio beige/", "Jubilife City Building 3.obj", "Jubilife City Building 3.mtl", (model) => {
     
        // Transformación del modelo  (Segunda fila)
        model.position.set(-185, 0, 26);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio cafe simple/", "Jubilife City Building 5.obj", "Jubilife City Building 5.mtl", (model) => {
     
        // Transformación del modelo   (Segunda fila)
        model.position.set(-58, 0, 7);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio cafe/", "Jubilife City Building 3.obj", "Jubilife City Building 3.mtl", (model) => {
     
        // Transformación del modelo  (Tercera fila)
        model.position.set(-190, 0, 96.5);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo  (Tercera fila)
        model.position.set(-228, 0, -147);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio beige/", "Jubilife City Building 3.obj", "Jubilife City Building 3.mtl", (model) => {
     
        // Transformación del modelo  (Cuarta fila)
        model.position.set(-188, 0, -52);
        model.scale.set(0.17, 0.17, 0.17);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio cafe/", "Jubilife City Building 3.obj", "Jubilife City Building 3.mtl", (model) => {
     
        // Transformación del modelo   (Cuarta fila)
        model.position.set(-220, 0, -190);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio beige espaldas/", "Jubilife City Building 4.obj", "Jubilife City Building 4.mtl", (model) => {
     
        // Transformación del modelo  (Quinta fila)
        model.position.set(-191, 0, -17);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio cafe simple/", "Jubilife City Building 5.obj", "Jubilife City Building 5.mtl", (model) => {
     
        // Transformación del modelo   (Quinta fila)
        model.position.set(-380, 0, -100);
        model.scale.set(0.18, 0.18, 0.18);
       

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //////////////////////////////////////////////////////////////////////////////////////////
    //Edificios ilera derecha
    //
    loadOBJWithMTL("/Assets/modelos/City/Edificio cafe/", "Jubilife City Building 3.obj", "Jubilife City Building 3.mtl", (model) => {
     
        // Transformación del modelo   (Quinta fila)
        model.position.set(168, 0, -227);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio celeste alto/", "Jubilife City Building 2.obj", "Jubilife City Building 2.mtl", (model) => {
     
        // Transformación del modelo   (Quinta fila)
        model.position.set(226, 0, -160);
        model.scale.set(0.17, 0.17, 0.17);
      

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/EstacionTren/", "Saffron City Station.obj", "Saffron City Station.mtl", (model) => {
     
        // Transformación del modelo  (TREN)
        model.position.set(296, 0, -125);
        model.scale.set(0.17, 0.17, 0.17);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/City/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo   (Alado del tren)
        model.position.set(207, 0, 119);
        model.scale.set(0.17, 0.17, 0.17);
        model.rotation.y = THREE.MathUtils.degToRad(90);
      

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });
    
    loadOBJWithMTL("/Assets/modelos/City/Edificio cafe/", "Jubilife City Building 3.obj", "Jubilife City Building 3.mtl", (model) => {
     
        // Transformación del modelo   (Alado del tren)
        model.position.set(206, 0, -150);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
      

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio celeste ancho/", "Jubilife City Building.obj", "Jubilife City Building.mtl", (model) => {
     
        // Transformación del modelo   (Segunda fila)
        model.position.set(236, 0, -1);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio cafe simple/", "Jubilife City Building 5.obj", "Jubilife City Building 5.mtl", (model) => {    
        // Transformación del modelo   (Segunda fila)
        model.position.set(32, 0, 15);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio cilindro/", "Jubilife City Building 4.obj", "Jubilife City Building 4.mtl", (model) => {
     
        // Transformación del modelo   
        model.position.set(240, 0, 4);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //---------------------------------------------------------------
    //Edificios centro 
    ///
    loadOBJWithMTL("/Assets/modelos/City/Edificio cafe/", "Jubilife City Building 3.obj", "Jubilife City Building 3.mtl", (model) => {
     
        // Transformación del modelo   CEN
        model.position.set(123, 0, 43);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio beige/", "Jubilife City Building 3.obj", "Jubilife City Building 3.mtl", (model) => {
     
        // Transformación del modelo   IZ
        model.position.set(-40, 0, 40);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio celeste ancho/", "Jubilife City Building.obj", "Jubilife City Building.mtl", (model) => {
     
        // Transformación del modelo   DER
        model.position.set(58, 0, 110);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //---------------------------------------------------------------
    //Locales
    ///
    loadOBJWithMTL("/Assets/modelos/Urban/Restaurante/", "Kimono Dance Theater.obj", "Kimono Dance Theater.mtl", (model) => {
     
        // Transformación del modelo 
        model.position.set(27, 0, 160);
        model.scale.set(0.175, 0.175, 0.175);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Restaurante 2/", "Seven Stars Restaurant.obj", "Seven Stars Restaurant.mtl", (model) => {
     
        // Transformación del modelo  
        model.position.set(100, 0, 220);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/Edificio rojo/", "Jubilife City Building 1.obj", "Jubilife City Building 1.mtl", (model) => {
     
        // Transformación del modelo  
        model.position.set(135, 0, 220);
        model.scale.set(0.18, 0.18, 0.18);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //
    //Pabellon
    //
    loadOBJWithMTL("/Assets/modelos/City/GranB/", "Pokemon Contest Hall.obj", "Pokemon Contest Hall.mtl", (model) => {
     
        // Transformación del modelo   
        model.position.set(-7.5, 0, -250.0);
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    const textureLoader = new THREE.TextureLoader();
    loadOBJWithMTL("/Assets/modelos/Urban/Pino/", "ORAS_Evergreen.obj", "ORAS_Evergreen.mtl", (model) => {
        model.position.set(-82, 0, -190.0);
        model.scale.set(0.34, 0.34, 0.34);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                // Carga las texturas dentro del traverse para evitar errores de scope
                const texture = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B.png");
                const alphaMap = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B - copia.png");
    
                child.material = new THREE.MeshStandardMaterial({
                    map: texture,
                    alphaMap: alphaMap,
                    transparent: true,
                    alphaTest: 0.5,
                    depthWrite: false,
                    side: THREE.DoubleSide
                });
                child.castShadow = true;
            }
        });
    
        // Resto de tu código (bounding box, etc.)
        const boundingBox = new THREE.Box3().setFromObject(model);
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pino/", "ORAS_Evergreen.obj", "ORAS_Evergreen.mtl", (model) => {
        model.position.set(68, 0, -190);
        model.scale.set(0.34, 0.34, 0.34);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                // Carga las texturas dentro del traverse para evitar errores de scope
                const texture = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B.png");
                const alphaMap = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B - copia.png");
    
                child.material = new THREE.MeshStandardMaterial({
                    map: texture,
                    alphaMap: alphaMap,
                    transparent: true,
                    alphaTest: 0.5,
                    depthWrite: false,
                    side: THREE.DoubleSide
                });
                child.castShadow = true;
            }
        });
    
        // Resto de tu código (bounding box, etc.)
        const boundingBox = new THREE.Box3().setFromObject(model);
        scene.add(model);
        loadedAssets++;
    });

    ///////////////////////////////////////////////////////////////////////////////////
    ////Luces
    /////

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(22, 0, 5);
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(22, 0, -70);
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(22, 0, -140);
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(22, 0, -205);
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });
    
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-42, 0, -56);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });
      
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-42, 0, 9);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-42, 0, 79);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });
      
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-42, 0, 154);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    ///Pabellon Luces
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-2, 0, 82);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-165, 0, 82);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-2, 0, 195);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-165, 0, 195);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });


    //Luces abajo----------------------
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-15, 0, -91);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(148, 0, -91);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-15, 0, 19);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(148, 0, 19);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-216, 0, 19);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(-82, 0, 19);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(215, 0, 19);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/City/", "streetlight.obj", "streetlight.mtl", (model) => {
        model.position.set(350, 0, 19);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

}

// -- CHARACTER MOVEMENT --

const inputActions = {
    up: "w",
    bottom: "s",
    left: "a",
    right: "d",
    interact: "e",
}

document.addEventListener("keydown", function (event) {

    if(currentPlayerCharacter.canMove && !gamePaused && !gameFinished) {

        const pressedKey = event.key.toLowerCase();

        if(pressedKey == inputActions["up"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.z -= 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(180.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.z += 5;
            }
        }
    
        if(pressedKey == inputActions["bottom"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.z += 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(0.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.z -= 5;
            }
        }
    
        if(pressedKey == inputActions["right"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.x += 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(90.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.x -= 5;
            }
        }
    
        if(pressedKey == inputActions["left"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.x -= 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(270.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.x += 5;
            }
        }
    
        if(pressedKey == inputActions["interact"] && currentPlayerCharacter.name == 'police-man') {
            
            const trap = currentPlayerCharacter.setTrap();
            
            if(trap != null) {
    
                trap.boundingBox.setFromObject(trap.model);
    
                powerUps.push(trap);
                scene.add(trap.model);
            }
        }
    
        if(Object.values(inputActions).includes(pressedKey)) {
            
            isCollidingWithPowerUp(currentPlayerCharacter);
    
            isCollidingWithEnemy(currentPlayerCharacter);
    
            if(currentPlayerCharacter.name == 'mouse') {
    
                isCollidingWithCheeses();
            }
        }

    }

});


document.addEventListener("keyup", function (event) { 

    const unpressedKey = event.key.toLowerCase();

    const inputActionsValues = Object.values(inputActions);
    
    if (inputActionsValues.includes(unpressedKey)) { 
        currentPlayerCharacter.updateActionAnimation("idle");
    }

});




// -- GAME START --

initGame();
animate();


function animate() {

    requestAnimationFrame(animate);
    console.log("Assets cargados:", loadedAssets, "/", totalAssets);

    if(loadedAssets >= totalAssets) {
        console.log("Todos los assets cargados - Renderizando...");
        const delta = clock.getDelta();
        renderer.render(scene, camera);
    }
 
}

function insertRecord(playerName, score) {

    $.ajax({
        type: "POST",
        url: "/services/InsertRecord.php",
        data: {
            player_name: playerName,
            score: score
        }
    }).done(function(data) {

    }).fail(function(e) {
        
    });
}