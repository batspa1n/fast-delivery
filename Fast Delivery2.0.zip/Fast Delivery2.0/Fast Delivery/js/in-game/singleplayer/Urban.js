import * as THREE from '../../threejs/three.module.js';
import {MTLLoader} from '../../threejs/MTLLoader.js';
import {OBJLoader} from '../../threejs/OBJLoader.js';
import {FBXLoader} from '../../threejs/FBXLoader.js';

document.body.setAttribute('data-canvas-state', 
    document.getElementById('game-canvas') ? 'Existe' : 'No existe');


// --- PAUSE ---
let gamePaused = false;
const pauseModal = new bootstrap.Modal(document.getElementById('pause-modal'));

const pauseButton = document.getElementById('pause-button');
pauseButton.addEventListener('click', function () { 
    gamePaused = true;
    pauseModal.show();

});

document.getElementById('play-button').addEventListener('click', function () { 
    gamePaused = false;
    pauseModal.hide();
});

// --- END PAUSE --

// -- MATCH --
const scoreMultiplier = localStorage.getItem('difficulty') == 'fácil' ? 100 : 150;
const winnerModal = new bootstrap.Modal(document.getElementById('winner-modal'));
const winnerText = document.getElementById('winner-text');
const winnerName = document.getElementById('winner-name');
let gameFinished = false;

// -- SCENE --
const scene = new THREE.Scene();
new THREE.TextureLoader().load("/Assets/img/Fondo_default.png", function(texture) {

    scene.background = texture;
});


// -- CAMERA --
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight);
camera.position.set(0, 250, 0);
camera.rotateX(THREE.MathUtils.degToRad(-90.0));

// -- RENDERER --
const renderer = new THREE.WebGLRenderer({canvas: document.getElementById('game-canvas')});
renderer.setSize(window.innerWidth, window.innerHeight - 1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Opcional: especifica el tipo de sombra que deseas (opciones: BasicShadowMap, PCFShadowMap, PCFSoftShadowMap)
document.body.appendChild(renderer.domElement);

// Resize game
window.addEventListener("resize", function() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight - 1);
    renderer.render(scene, camera);
});

let loadedAssets = 0;
const totalAssets = 31;


// -- COLLISIONS --
let boundingBoxes = [];
let floorBoundingBox = null;

function isCollidingWithScenario(character) {
  
    for (const boundingBox of boundingBoxes) {

        if (boundingBox.intersectsBox(character.boundingBox)) {

            return true;
        }
    }

    return false;
}

function isOutOfScenario(character) {
    
    const position = character.model.position;

    return (position.x < -130 || position.x > 130 ||
    position.z < -130 || position.z > 130);
}

// -- PARTICLES --
let particles = null;

// -- RAYCAST -- 
var rayCaster = new THREE.Raycaster();

// -- STATS --
const SPEED = 8;
const POLICE_RANGE = 10;

// -- CLOCK --
const clock = new THREE.Clock();

// -- DIFFICULTY LIGHTS --

const difficultyLights = [];

// -- OBJETOS CON COLISIÓN --
let objectsWithBoundingBox = [];

// -- ASSETS LOADING FUNCTIONS --

function loadOBJWithMTL(path, objFile, mtlFile, onModelLoaded) {

    const mtlLoader = new MTLLoader();
    mtlLoader.setPath(path);

    // Load materials from MTL file
    mtlLoader.load(mtlFile, (materials) => {
    
        const objLoader = new OBJLoader();
        objLoader.setMaterials(materials)
        objLoader.setPath(path);
        objLoader.load(objFile, (model) => {

            onModelLoaded(model);
        });
    
    });

}

// -- GAME INITIALIZE --

function initGame() {
    
    initLights();
    initModels();
    initParticles();
}


function initParticles() {

    const material = new THREE.PointsMaterial({
        size: 0.1,
        vertexColors: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        transparent: true
      });

      const geometry = new THREE.BufferGeometry();
      const positions = [];
      const colors = [];
      const numParticles = 500;

      for (let i = 0; i < numParticles; i++) {

        const position = new THREE.Vector3(
          Math.random() * 2 - 1,
          124.5,
          Math.random() * 2 - 1
        ).multiplyScalar(2);

        positions.push(position.x, position.y, position.z);

        const color = new THREE.Color();
        color.setRGB(Math.random(), Math.random(), Math.random());
        colors.push(color.r, color.g, color.b);
      }

      geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

      particles = new THREE.Points(geometry, material);

      particles.visible = false;

      scene.add(particles);
}

function initLights() {
    // 1. LUZ AMBIENTAL PRINCIPAL - Más intensa y con tono cálido
    const ambientLight = new THREE.AmbientLight(0xfff4e6, 0.39); // Luz cálida, intensidad aumentada
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xFFFFFF, 0.5);
    directionalLight.position.set(50, 100, 50);
    directionalLight.castShadow = true; // Opcional: sombras dinámicas
    scene.add(directionalLight);

    const hemisphereLight = new THREE.HemisphereLight(0x87CEEB, 0x8B4513, 0.2);
    scene.add(hemisphereLight);


    // 6. CONFIGURACIONES DEL RENDERER PARA MEJOR ILUMINACIÓN
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.3;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.enabled = true;
}
function initModels() {

    // Piso del escenario

    // Se indica la carpeta donde se encuentra el OBJ y el MTL,
    // el archivo OBJ y el MTL. 
    // Al final se pasa una función que se ejecuta al cargar el modelo,
    // aquí se pueden modificar las propiedades del modelo y agregarlo a la escena
    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Pavimento.obj", "Pavimento.mtl", (model) => {
     
        model.scale.set(0.32, 0.10, 0.195);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.receiveShadow = true; // Permitir que el modelo genere sombras
            }
          });

        floorBoundingBox = new THREE.Box3();
        floorBoundingBox.setFromObject(model);

        scene.add(model);
        loadedAssets++;
    });

    //MODELOS
    //Depa morados
    //
    loadOBJWithMTL("/Assets/modelos/Urban/Depa/", "Hearthome City Building.obj", "Hearthome City Building.mtl", (model) => {
        model.position.set(-280.0, 0, -191.0);
        model.scale.set(0.175, 0.175, 0.175);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = true;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Depa/", "Hearthome City Building.obj", "Hearthome City Building.mtl", (model) => {
        model.position.set(-245.0, 0, -191.0);
        model.scale.set(0.175, 0.175, 0.175);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = true;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });
    //
    //Depa grises
    //
    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(-160, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(-117, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(-74, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(-31, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        model.position.set(12, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo
        model.position.set(55, 0, 157.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión 
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //Calles
    //
    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Calle 1.obj", "Calle 1.mtl", (model) => {
        
        model.position.set(60, 0, 160.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Calle 2.obj", "Calle 2.mtl", (model) => {
        
        model.position.set(60, 0, 0.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Calle 2.obj", "Calle 2.mtl", (model) => {
        
        model.position.set(60, 0, -115.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Calle 3.obj", "Calle 3.mtl", (model) => {
        
        model.position.set(-19, 0, -187.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Calle 4.obj", "Calle 4.mtl", (model) => {
        
        model.position.set(110, 0, -228.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //Depas grises
    //

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo
        model.position.set(-405, 0, 70.0);
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo
        model.position.set(-362, 0, 70.0);
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo  (Segunda ilera)
        model.position.set(-162, 0, 45);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo   (Segunda ilera)
        model.position.set(-118, 0, 45);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo  (Primera ilera)
        model.position.set(-360, 0, -47);
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo  (Primera ilera)
        model.position.set(-400, 0, -47);
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo  (Primera ilera)
        model.position.set(-157, 0, -72);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Striaton City Building 1/", "Striaton City Building 1.obj", "Striaton City Building 1.mtl", (model) => {
     
        // Transformación del modelo   (Primera ilera)
        model.position.set(-116, 0, -72);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //
    //Zona de casas
    //
    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(55, 0, -158);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(95, 0, -158);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(135, 0, -158);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(175, 0, -158);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(215, 0, -158);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(255, 0, -158);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, -40);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, 0);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, 40);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, 80);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, 120);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, 160);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //Ileras casas izquierda
    //
    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(80, 0, -40);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(80, 0, 0);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(80, 0, 40);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(80, 0, 80);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(80, 0, 120);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(80, 0, 160);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //Ileras casas derecha
    //
    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(125, 0, -40);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(125, 0, 0);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(125, 0, 40);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(125, 0, 80);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(125, 0, 120);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(125, 0, 160);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    //
    //Locales
    ///
    loadOBJWithMTL("/Assets/modelos/Urban/Restaurante/", "Kimono Dance Theater.obj", "Kimono Dance Theater.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(-170.0, 0, -160.0);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });
    
    loadOBJWithMTL("/Assets/modelos/Urban/Lab/", "Elm Pokémon Lab.obj", "Elm Pokémon Lab.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(-165.0, 0, -160.0);
        model.scale.set(0.19, 0.19, 0.19);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Floreria/", "Goldenrod Flower Shop.obj", "Goldenrod Flower Shop.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(-90.0, 0, -190.0);
        model.scale.set(0.2, 0.2, 0.2);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Fuente/", "Fountain.obj", "Fountain.mtl", (model) => {
     
        // Transformación del modelo (Fuente)
        model.position.set(-100, 0, -74.0);
        model.scale.set(0.35, 0.35, 0.35);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    const textureLoader = new THREE.TextureLoader();
    loadOBJWithMTL("/Assets/modelos/Urban/Pino/", "ORAS_Evergreen.obj", "ORAS_Evergreen.mtl", (model) => {
        model.position.set(-140, 0, -124.0);
        model.scale.set(0.34, 0.34, 0.34);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                // Carga las texturas dentro del traverse para evitar errores de scope
                const texture = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B.png");
                const alphaMap = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B - copia.png");
    
                child.material = new THREE.MeshStandardMaterial({
                    map: texture,
                    alphaMap: alphaMap,
                    transparent: true,
                    alphaTest: 0.5,
                    depthWrite: false,
                    side: THREE.DoubleSide
                });
                child.castShadow = true;
            }
        });
    
        // Resto de tu código (bounding box, etc.)
        const boundingBox = new THREE.Box3().setFromObject(model);
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pino/", "ORAS_Evergreen.obj", "ORAS_Evergreen.mtl", (model) => {
        model.position.set(-60, 0, -124.0);
        model.scale.set(0.34, 0.34, 0.34);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                // Carga las texturas dentro del traverse para evitar errores de scope
                const texture = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B.png");
                const alphaMap = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B - copia.png");
    
                child.material = new THREE.MeshStandardMaterial({
                    map: texture,
                    alphaMap: alphaMap,
                    transparent: true,
                    alphaTest: 0.5,
                    depthWrite: false,
                    side: THREE.DoubleSide
                });
                child.castShadow = true;
            }
        });
    
        // Resto de tu código (bounding box, etc.)
        const boundingBox = new THREE.Box3().setFromObject(model);
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pino/", "ORAS_Evergreen.obj", "ORAS_Evergreen.mtl", (model) => {
        model.position.set(-140, 0, 24.0);
        model.scale.set(0.34, 0.34, 0.34);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                // Carga las texturas dentro del traverse para evitar errores de scope
                const texture = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B.png");
                const alphaMap = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B - copia.png");
    
                child.material = new THREE.MeshStandardMaterial({
                    map: texture,
                    alphaMap: alphaMap,
                    transparent: true,
                    alphaTest: 0.5,
                    depthWrite: false,
                    side: THREE.DoubleSide
                });
                child.castShadow = true;
            }
        });
    
        // Resto de tu código (bounding box, etc.)
        const boundingBox = new THREE.Box3().setFromObject(model);
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pino/", "ORAS_Evergreen.obj", "ORAS_Evergreen.mtl", (model) => {
        model.position.set(-60, 0, 24.0);
        model.scale.set(0.34, 0.34, 0.34);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                // Carga las texturas dentro del traverse para evitar errores de scope
                const texture = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B.png");
                const alphaMap = textureLoader.load("/Assets/modelos/Urban/Pino/Chip_Wood_B - copia.png");
    
                child.material = new THREE.MeshStandardMaterial({
                    map: texture,
                    alphaMap: alphaMap,
                    transparent: true,
                    alphaTest: 0.5,
                    depthWrite: false,
                    side: THREE.DoubleSide
                });
                child.castShadow = true;
            }
        });
    
        // Resto de tu código (bounding box, etc.)
        const boundingBox = new THREE.Box3().setFromObject(model);
        scene.add(model);
        loadedAssets++;
    });


    //Pasto
    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Pasto.obj", "Pasto.mtl", (model) => {
        
        model.position.set(110, 0, 190.0);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Pasto 1.obj", "Pasto 1.mtl", (model) => {
        
        model.position.set(398, 0, -270.5);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Pasto 2.obj", "Pasto 2.mtl", (model) => {
        
        model.position.set(604, 0, -213);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Pasto 3.obj", "Pasto 3.mtl", (model) => {
        
        model.position.set(315, 0, -213);
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    ////////////////////////////////////////////////////////////////////////////
    ///Luces 
    /////////////////
    ////Depas grises
    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
            model.position.set(27, 0, 18);   
            model.scale.set(0.16, 0.16, 0.16);
            model.rotation.y = THREE.MathUtils.degToRad(-90);
        
            model.traverse((child) => {
                if (child.isMesh) {
                    child.material = new THREE.MeshStandardMaterial({
                        map: child.material.map, // Conserva la textura original
                        color: 0xffffff,        // Aclara el color base
                        roughness: 0.8,
                        metalness: 0.0
                    });
                    child.receiveShadow = true;
                }
            });
            scene.add(model);
            loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-53, 0, 18);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-143, 0, 18);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    /////////////////
    ////Depas grises 4
    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-149, 0, -93);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-149, 0, -205);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //----------------------------------------------

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-300, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-300, 0, 88);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-298, 0, 205);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //-------------------------------------------------------------------------
    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-235, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-115, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //-------------------------------------------------------------------------
    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-36, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(40, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(116, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(192, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //-------------------------------------------------------------------------
    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(72, 0, -10);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(72, 0, 159);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(277, 0, 10);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(277, 0, 98);    
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(277, 0, 180);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    
    //-------------------------------------------------------------------------
    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-36, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(40, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(116, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(192, 0, -25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //-------------------------------------------------------------------------
    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(132.5, 0, -140);   
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(132.5, 0, -56);     
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(132.5, 0, 26);  
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //---------------------------------------------

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-65.5, 0, 26);     
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-65.5, 0, -53.5); 
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-65.5, 0, -138); 
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-270, 0, 12); 
        model.scale.set(0.16, 0.16, 0.16);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-270, 0, -156); 
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

}

document.addEventListener("keydown", function (event) {

    if(currentPlayerCharacter.canMove && !gamePaused && !gameFinished) {

        const pressedKey = event.key.toLowerCase();

        if(pressedKey == inputActions["up"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.z -= 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(180.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.z += 5;
            }
        }
    
        if(pressedKey == inputActions["bottom"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.z += 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(0.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.z -= 5;
            }
        }
    
        if(pressedKey == inputActions["right"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.x += 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(90.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.x -= 5;
            }
        }
    
        if(pressedKey == inputActions["left"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.x -= 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(270.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.x += 5;
            }
        }
    
        if(pressedKey == inputActions["interact"] && currentPlayerCharacter.name == 'police-man') {
            
            const trap = currentPlayerCharacter.setTrap();
            
            if(trap != null) {
    
                trap.boundingBox.setFromObject(trap.model);
    
                powerUps.push(trap);
                scene.add(trap.model);
            }
        }
    
        if(Object.values(inputActions).includes(pressedKey)) {
            
            isCollidingWithPowerUp(currentPlayerCharacter);
    
            isCollidingWithEnemy(currentPlayerCharacter);
    
            if(currentPlayerCharacter.name == 'mouse') {
    
                isCollidingWithCheeses();
            }
        }

    }

});


document.addEventListener("keyup", function (event) { 

    const unpressedKey = event.key.toLowerCase();

    const inputActionsValues = Object.values(inputActions);
    
    if (inputActionsValues.includes(unpressedKey)) { 
        currentPlayerCharacter.updateActionAnimation("idle");
    }

});

// -- GAME START --

initGame();
animate();

function animate() {

    requestAnimationFrame(animate);
    console.log("Assets cargados:", loadedAssets, "/", totalAssets);

    if(loadedAssets >= totalAssets) {
        console.log("Todos los assets cargados - Renderizando...");
        const delta = clock.getDelta();
        renderer.render(scene, camera);
    }
 
}

function insertRecord(playerName, score) {

    $.ajax({
        type: "POST",
        url: "/services/InsertRecord.php",
        data: {
            player_name: playerName,
            score: score
        }
    }).done(function(data) {

    }).fail(function(e) {
        
    });
}