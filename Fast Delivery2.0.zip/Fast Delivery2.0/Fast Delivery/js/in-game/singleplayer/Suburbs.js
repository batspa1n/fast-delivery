import * as THREE from '../../threejs/three.module.js';
import {MTLLoader} from '../../threejs/MTLLoader.js';
import {OBJLoader} from '../../threejs/OBJLoader.js';
import {FBXLoader} from '../../threejs/FBXLoader.js';


document.body.setAttribute('data-canvas-state', 
    document.getElementById('game-canvas') ? 'Existe' : 'No existe');

// --- PAUSE ---
let gamePaused = false;
const pauseModal = new bootstrap.Modal(document.getElementById('pause-modal'));

const pauseButton = document.getElementById('pause-button');
pauseButton.addEventListener('click', function () { 
    gamePaused = true;
    pauseModal.show();

});

document.getElementById('play-button').addEventListener('click', function () { 
    gamePaused = false;
    pauseModal.hide();
});

// --- END PAUSE --

// -- MATCH --
const scoreMultiplier = localStorage.getItem('difficulty') == 'fácil' ? 100 : 150;
const winnerModal = new bootstrap.Modal(document.getElementById('winner-modal'));
const winnerText = document.getElementById('winner-text');
const winnerName = document.getElementById('winner-name');
let gameFinished = false;

// -- SCENE --
const scene = new THREE.Scene();
new THREE.TextureLoader().load("../Assets/img/Fondo_default.png", function(texture) {

    scene.background = texture;
});


// -- CAMERA --
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight);
camera.position.set(0, 250, 0);
camera.rotateX(THREE.MathUtils.degToRad(-90.0));

// -- RENDERER --
const renderer = new THREE.WebGLRenderer({canvas: document.getElementById('game-canvas')});
renderer.setSize(window.innerWidth, window.innerHeight - 1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Opcional: especifica el tipo de sombra que deseas (opciones: BasicShadowMap, PCFShadowMap, PCFSoftShadowMap)
document.body.appendChild(renderer.domElement);

// Resize game
window.addEventListener("resize", function() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight - 1);
    renderer.render(scene, camera);
});

let loadedAssets = 0;
const totalAssets = 31;


// -- COLLISIONS --
let boundingBoxes = [];
let floorBoundingBox = null;

function isCollidingWithScenario(character) {
  
    for (const boundingBox of boundingBoxes) {

        if (boundingBox.intersectsBox(character.boundingBox)) {

            return true;
        }
    }

    return false;
}

function isOutOfScenario(character) {
    
    const position = character.model.position;

    return (position.x < -130 || position.x > 130 ||
    position.z < -130 || position.z > 130);
}

// -- PARTICLES --
let particles = null;

// -- RAYCAST -- 
var rayCaster = new THREE.Raycaster();

// -- STATS --
const SPEED = 8;
const POLICE_RANGE = 10;

// -- CLOCK --
const clock = new THREE.Clock();

// -- DIFFICULTY LIGHTS --

const difficultyLights = [];

// -- OBJETOS CON COLISIÓN --
let objectsWithBoundingBox = [];

// -- SELECTED CHARACTER --
let singlePlayerSelectedCharacter = 'mouse';


// -- ASSETS LOADING FUNCTIONS --

function loadOBJWithMTL(path, objFile, mtlFile, onModelLoaded) {

    const mtlLoader = new MTLLoader();
    mtlLoader.setPath(path);

    // Load materials from MTL file
    mtlLoader.load(mtlFile, (materials) => {
    
        const objLoader = new OBJLoader();
        objLoader.setMaterials(materials)
        objLoader.setPath(path);
        objLoader.load(objFile, (model) => {

            onModelLoaded(model);
        });
    
    });

}

// -- GAME INITIALIZE --

function initGame() {
    
    initLights();
    initModels();
    initParticles();
}


function initParticles() {

    const material = new THREE.PointsMaterial({
        size: 0.1,
        vertexColors: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        transparent: true
      });

      const geometry = new THREE.BufferGeometry();
      const positions = [];
      const colors = [];
      const numParticles = 500;

      for (let i = 0; i < numParticles; i++) {

        const position = new THREE.Vector3(
          Math.random() * 2 - 1,
          124.5,
          Math.random() * 2 - 1
        ).multiplyScalar(2);

        positions.push(position.x, position.y, position.z);

        const color = new THREE.Color();
        color.setRGB(Math.random(), Math.random(), Math.random());
        colors.push(color.r, color.g, color.b);
      }

      geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

      particles = new THREE.Points(geometry, material);

      particles.visible = false;

      scene.add(particles);
}

function initLights() {
    // 1. LUZ AMBIENTAL PRINCIPAL - Más intensa y con tono cálido
    const ambientLight = new THREE.AmbientLight(0xfff4e6, 0.39); // Luz cálida, intensidad aumentada
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xFFFFFF, 0.5);
    directionalLight.position.set(50, 100, 50);
    directionalLight.castShadow = true; // Opcional: sombras dinámicas
    scene.add(directionalLight);

    const hemisphereLight = new THREE.HemisphereLight(0x87CEEB, 0x8B4513, 0.2);
    scene.add(hemisphereLight);


    // 6. CONFIGURACIONES DEL RENDERER PARA MEJOR ILUMINACIÓN
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.3;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.enabled = true;
}
function initModels() {

    // Piso del escenario

    // Se indica la carpeta donde se encuentra el OBJ y el MTL,
    // el archivo OBJ y el MTL. 
    // Al final se pasa una función que se ejecuta al cargar el modelo,
    // aquí se pueden modificar las propiedades del modelo y agregarlo a la escena
    loadOBJWithMTL("/Assets/modelos/Urban/calles/", "Pavimento.obj", "Pavimento.mtl", (model) => {
     
        model.scale.set(0.32, 0.10, 0.195);
        model.traverse(function(child) {
            if (child.isMesh) {
              child.receiveShadow = true; // Permitir que el modelo genere sombras
            }
          });

        floorBoundingBox = new THREE.Box3();
        floorBoundingBox.setFromObject(model);

        scene.add(model);
        loadedAssets++;
    });

    //MODELOS
    //////////////////////////////////////////////////////////////////////////////////////////7
    //Zona casa vallas
    //
    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-292.0, 0, -157.0);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-237.0, 0, -157.0);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-182.0, 0, -157.0);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-127.0, 0, -157.0);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-72.0, 0, -157.0);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    /////////////////////////////////////////////////////////////////////
    //Zona casas vaya baja
    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-250.0, 0, -58);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-195, 0, -58);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-140, 0, -58);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-85, 0, -58);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa roja/", "Pokémon Day Care.obj", "Pokémon Day Care.mtl", (model) => {
        model.position.set(-30, 0, -58);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //Zona casas azules arriba
    ////////////
    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(-160, 0, 27);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(-117, 0, 27);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });


    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(-10, 0, 27);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(35, 0, 27);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(80, 0, 27);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //Zona casas azules abajo
    ////////////
    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(-392, 0, 63.5);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(-350, 0, 63.5);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(-242, 0, 63.5);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(-196.7, 0, 63.5);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
        model.position.set(-154.5, 0, 63.5);
        model.scale.set(0.178, 0.178, 0.178);
    
        model.traverse(function(child) {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;
    });

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //Zona casas azules abaja
    //
    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
     
        model.position.set(-171, 0, 157.0);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
     
        model.position.set(-131, 0, 157.0);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
     
        model.position.set(-88, 0, 157.0);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
     
        model.position.set(-45, 0, 157.0);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
     
        model.position.set(-2, 0, 157.0);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
     
        model.position.set(40, 0, 157.0);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.castShadow = false;
                // Fuerza materiales opacos
                child.material.transparent = false;
                child.material.opacity = 1.0;
                child.material.depthWrite = true;
            }
        });
    
        const boundingBox = new THREE.Box3().setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;
    
        scene.add(model);
        loadedAssets++;

    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/casa azul/", "Player's House.obj", "Player's House.mtl", (model) => {
     
        // Transformación del modelo
        model.position.set(81.5, 0, 157.0);
        model.scale.set(0.178, 0.178, 0.178);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
        });

        // Crear la caja de colisión 
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    ///////////////////////////////////////////////////////////////////////////////////
    //Zona de casas rojas
    //
    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, -154);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, -114);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, -74);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, -34);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });
    
    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha) 
        model.position.set(257, 0, 80);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, 120);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas esquina derecha)
        model.position.set(257, 0, 160);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    ///////////////////////////////////////////////////////////
    //Ileras casas derecha
    //
    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas izquierda)
        model.position.set(80, 0, -154);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas izquierda)
        model.position.set(80, 0, -114);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas izquierda)
        model.position.set(80, 0, -74);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas izquierda)
        model.position.set(80, 0, -34);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas izquierda)
        model.position.set(80, 0, 80);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas izquierda)
        model.position.set(80, 0, 120);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas izquierda)
        model.position.set(80, 0, 160);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(-90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(125, 0, -154);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(125, 0, -114);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(125, 0, -74);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(125, 0, -34);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(125, 0, 80);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(125, 0, 120);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Urban/Pallet Town House/", "Pallet Town House.obj", "Pallet Town House.mtl", (model) => {
     
        // Transformación del modelo   (Casas derecha)
        model.position.set(125, 0, 160);
        model.scale.set(0.19, 0.19, 0.19);
        model.rotation.y = THREE.MathUtils.degToRad(90);

        model.traverse(function(child) {
            if (child.isMesh) {
              child.castShadow = true; // Permitir que el modelo genere sombras
            }
          });

        // Crear la caja de colisión
        const boundingBox = new THREE.Box3();
        boundingBox.uuid = model.uuid;
        boundingBox.setFromObject(model);
        boundingBoxes.push(boundingBox);
        objectsWithBoundingBox.push(model);
        model.boundBox = boundingBox;

        // Agregarlo al escenario
        scene.add(model);
        loadedAssets++;
    });

    ////////////////////////////////////////////////////////////////////////////////////////
    //Calles
    //
    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 1.obj", "Calle 1.mtl", (model) => {
        
        model.position.set(60, 0, 160.0); ///(Calle 6 linea Azules)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 2.obj", "Calle 2.mtl", (model) => {
        
        model.position.set(-19, 0, -160.0); ///(Calle 6 abajo rojos)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    
    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 4.obj", "Calle 4.mtl", (model) => {
        
        model.position.set(60, 0, 0.0);  ///(Calle 4 azules)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 3.obj", "Calle 3.mtl", (model) => {
        
        model.position.set(-19, 0, -187.0); ///(Calle 6 arriba rojos)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });
    
    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 5.obj", "Calle 5.mtl", (model) => {
        
        model.position.set(130, 0, 190.0);  //(Calle de 6 Azules)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 8.obj", "Calle 8.mtl", (model) => {
        
        model.position.set(604, 0, -213); //(Calle fila roja derecha baja)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 9.obj", "Calle 9.mtl", (model) => {
        
        model.position.set(604, 0, -213); //(Calle fila roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 6.obj", "Calle 6.mtl", (model) => {
        
        model.position.set(315, 0, -213);         //(Calle ileras roja derecha baja)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/calles/", "Calle 7.obj", "Calle 7.mtl", (model) => {
        
        model.position.set(315, 0, -213);    //(Calle ileras roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    ////////////////////////////////////////////////////////////////////////////
    ////Luces
    //////////////////
    //Luces ileras casas derecha
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(275, 0, -90);    //(Calle ileras roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(275, 0, -20);    //(Calle ileras roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(275, 0, 60);    //(Calle ileras roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });
    ////////
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-62, 0, -88);    //(Calle ileras roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-62, 0, -170);    //(Calle ileras roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-62, 0, -239);    //(Calle ileras roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //---------------------------------------------------------

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(275, 0, 133);    //(Calle ileras roja derecha abajo)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(275, 0, 213);    //(Calle ileras roja derecha abajo)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(180);

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });
    //////
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-62, 0, 64);    //(Calle ilera roja derecha abajo)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-62, 0, -15);    //(Calle ilera roja derecha abajo)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    ////Luces fila casas derechas //////////////////////////////////
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(130, 0, -88);    //(Calle fila roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(130, 0, -170);    //(Calle fila roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(130, 0, -239);    //(Calle fila roja derecha arriba)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });
    ////
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(130, 0, 64);    //(Calle fila roja derecha abajo)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(130, 0, -15);    //(Calle fila roja derecha abajo)
        model.scale.set(0.16, 0.16, 0.16);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    ///Luces fila casas rojas izquierda////////////////////////////////////////////////////////
    ////////////
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-95, 0, -24);    //(Calle fila roja arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-210, 0, -24);    //(Calle fila roja arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-325, 0, -24);    //(Calle fila roja arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });
    //---------------------
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(55, 0, -196);    //(Calle fila roja abajo)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-60, 0, -196);    //(Calle fila roja abajo)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-175, 0, -196);    //(Calle fila roja abajo)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    ///Luces casas azules 4 y 6 ///////////////////////////////////////////////////
    ///////////////////////
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-140, 0, -100);    //(Calle fila arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(55, 0, -103);    //(Calle fila arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-68, 0, -103);    //(Calle fila arriba)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    //------------
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-94, 0, 193);    //(Calle fila abajo)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
            
        model.position.set(-218, 0, 193);    //(Calle fila abajo)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
        
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-287, 0, 193);      //(Calle fila abajo)
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    
    ///Luces fila casas azules ///////////////////////////////////////////////////
    ///////////////////////
    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(55, 0, 25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-25, 0, 25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-105, 0, 25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

    loadOBJWithMTL("/Assets/modelos/Suburbio/", "streetlight.obj", "streetlight.mtl", (model) => {
        
        model.position.set(-185, 0, 25);   
        model.scale.set(0.16, 0.16, 0.16);
        model.rotation.y = THREE.MathUtils.degToRad(-90);
    
        model.traverse((child) => {
            if (child.isMesh) {
                child.material = new THREE.MeshStandardMaterial({
                    map: child.material.map, // Conserva la textura original
                    color: 0xffffff,        // Aclara el color base
                    roughness: 0.8,
                    metalness: 0.0
                });
                child.receiveShadow = true;
            }
        });
        scene.add(model);
        loadedAssets++;
    });

}

// -- CHARACTER MOVEMENT --

const inputActions = {
    up: "w",
    bottom: "s",
    left: "a",
    right: "d",
    interact: "e",
}

document.addEventListener("keydown", function (event) {

    if(currentPlayerCharacter.canMove && !gamePaused && !gameFinished) {

        const pressedKey = event.key.toLowerCase();

        if(pressedKey == inputActions["up"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.z -= 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(180.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.z += 5;
            }
        }
    
        if(pressedKey == inputActions["bottom"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.z += 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(0.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.z -= 5;
            }
        }
    
        if(pressedKey == inputActions["right"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.x += 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(90.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.x -= 5;
            }
        }
    
        if(pressedKey == inputActions["left"]) {
    
            if(!isCollidingWithScenario(currentPlayerCharacter) && !isOutOfScenario(currentPlayerCharacter)) {
    
                currentPlayerCharacter.model.position.x -= 1 * currentPlayerCharacter.speedMultiplier;
                currentPlayerCharacter.model.rotation.y = THREE.MathUtils.degToRad(270.0);
                currentPlayerCharacter.updateActionAnimation("run");
                currentPlayerCharacter.updateLightPosition();
            }
            else {
                currentPlayerCharacter.model.position.x += 5;
            }
        }
    
        if(pressedKey == inputActions["interact"] && currentPlayerCharacter.name == 'police-man') {
            
            const trap = currentPlayerCharacter.setTrap();
            
            if(trap != null) {
    
                trap.boundingBox.setFromObject(trap.model);
    
                powerUps.push(trap);
                scene.add(trap.model);
            }
        }
    
        if(Object.values(inputActions).includes(pressedKey)) {
            
            isCollidingWithPowerUp(currentPlayerCharacter);
    
            isCollidingWithEnemy(currentPlayerCharacter);
    
            if(currentPlayerCharacter.name == 'mouse') {
    
                isCollidingWithCheeses();
            }
        }

    }

});

document.addEventListener("keyup", function (event) { 

    const unpressedKey = event.key.toLowerCase();

    const inputActionsValues = Object.values(inputActions);
    
    if (inputActionsValues.includes(unpressedKey)) { 
        currentPlayerCharacter.updateActionAnimation("idle");
    }

});


// -- GAME START --

initGame();
animate();


function animate() {

    requestAnimationFrame(animate);
    console.log("Assets cargados:", loadedAssets, "/", totalAssets);

    if(loadedAssets >= totalAssets) {
        console.log("Todos los assets cargados - Renderizando...");
        const delta = clock.getDelta();
        renderer.render(scene, camera);
    }
 
}

function insertRecord(playerName, score) {

    $.ajax({
        type: "POST",
        url: "/services/InsertRecord.php",
        data: {
            player_name: playerName,
            score: score
        }
    }).done(function(data) {

    }).fail(function(e) {
        
    });
}