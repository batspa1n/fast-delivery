
class Cheese {

    constructor(name, model, boundingBox) {

        this.name = name;
        this.model = model;
        this.boundingBox = boundingBox;

    }

}


export {
    Cheese
}