import { initializeApp } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-auth.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAXVGvvMaGlOgT8xvq10EZ0a2kSPpA1Cho",
    authDomain: "policias-vs-ratones.firebaseapp.com",
    projectId: "policias-vs-ratones",
    storageBucket: "policias-vs-ratones.appspot.com",
    messagingSenderId: "872110097470",
    appId: "1:872110097470:web:ef18ee3aef91342e203d6f"
};
  
// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
const auth = getAuth();
auth.languageCode = "es";


// Check if user is authenticated
auth.onAuthStateChanged(function(user) {

    if(user == null) {
        
        window.location.replace('/login.html');
        localStorage.clear();
    }
    else {
        
        localStorage.setItem("currentUserUid", user.uid);
        localStorage.setItem("currentPlayerName", user.displayName);
    }

})