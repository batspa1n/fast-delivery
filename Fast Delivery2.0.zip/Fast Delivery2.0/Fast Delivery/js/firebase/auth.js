import { initializeApp } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js";
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-auth.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAXVGvvMaGlOgT8xvq10EZ0a2kSPpA1Cho",
    authDomain: "policias-vs-ratones.firebaseapp.com",
    projectId: "policias-vs-ratones",
    storageBucket: "policias-vs-ratones.appspot.com",
    messagingSenderId: "872110097470",
    appId: "1:872110097470:web:ef18ee3aef91342e203d6f"
};
  
// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
const auth = getAuth();
auth.languageCode = "es";

const loginButton = document.getElementById('login-button');
loginButton.addEventListener("click", login);

async function login() { 

    const provider = new GoogleAuthProvider();

   await signInWithPopup(auth, provider)
    .then((result) => {

        const user = result.user;
        localStorage.setItem("currentUserUid", user.uid);

    })
    .catch((error) => {

    });

}

auth.onAuthStateChanged(function(user) {

    if(user) {
        
        localStorage.setItem("currentUserUid", user.uid);
        localStorage.setItem("currentPlayerName", user.displayName);
        window.location.replace('/');
    }
    else {
        
        localStorage.clear();
    }

})


async function logout() {

    signOut(auth)
    .then((result) => {
        console.log('ya se salió')
    })
    .catch((error) => {
        console.log('ya valió ' + error)
    }); 

}