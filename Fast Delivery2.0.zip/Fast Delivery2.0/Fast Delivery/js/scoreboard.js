class Record {

constructor(rank, player_name, score, created_at){
    this.rank = rank;
    this.player_name = player_name;
    this.score = score;
    this.created_at = created_at;
}

get descripcion(){
    
    let row = document.createElement('tr');
    row.id = 'row-' + this.index;
    row.innerHTML = `
        <td class="rank-title"><span class="d-flex justify-content-center text-center">${this.rank}</span></td>
        <td class="player-title"><span class="d-flex justify-content-center text-center">${this.player_name}</span></td>
        <td class="score-title"><span class="d-flex justify-content-center text-center">${this.score}</span></td>
    `
    return row;
}

}

$(document).ready(function () {

    getScoreboard();

    function insertRecord(playerName, score) {

        $.ajax({
            type: "POST",
            url: "/services/InsertRecord.php",
            data: {
                player_name: playerName,
                score: score
            }
        }).done(function(data) {
    
        }).fail(function(e) {
            
        });
    }

    function getScoreboard() {

        $.ajax({
            type: "GET",
            url: "/services/GetScoreboard.php",
        }).done(function(data) {
    
            let tbody = document.getElementById('scoreboard-table-body');
            let scoreboard = [];
    
            data.forEach((p, index) => {
                const record = new Record(index + 1, p.player_name, p.score, p.created_at);
                scoreboard.push(record);
    
                tbody.appendChild(record.descripcion);
            });
    
        }).fail(function(e) {
    
            let row = document.createElement('tr');
            row.id = 'row-' + this.index;
            row.innerHTML = `
                <td class="rank-title"><span class="d-flex justify-content-center text-center"></span></td>
                <td class="rank-title"><span class="d-flex justify-content-center text-center">Sin registros</span></td>
                <td class="rank-title"><span class="d-flex justify-content-center text-center"></span></td>
            `       
            let tbody = document.getElementById('scoreboard-table-body');
    
            tbody.appendChild(row);
            
        });
    }

});