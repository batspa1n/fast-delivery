
$(document).ready(function () {
    

// Funcion para crear las tablas con la información

function createTable(response, tableId){

    let posts = response.data;
    let tbody = document.createElement('tbody');
    for (let i = 0; i < posts.length; i++) {
        let post = posts[i];
        let tr = document.createElement('tr');
        let td1 = document.createElement('td');
        td1.innerHTML = post.created_time;
        tr.appendChild(td1);
        let td2 = document.createElement('td');
        td2.innerHTML = post.message;
        tr.appendChild(td2);
        tbody.appendChild(tr);
    }
    let table = document.getElementById(tableId);
    table.appendChild(tbody);
    
    }


    // Obtener todos los posts de la página
    window.fbAsyncInit = function () {
    FB.init({
        appId: "1652882198560376", 
        autoLogAppEvents: true,
        xfbml: true,
        version: "v16.0",
    });

    FB.api(
        "/101779962937694/feed",
        "GET",
        {
            access_token:
            "EAAXfSaBMZCngBAGzx9mRspUpfd2BesgJa0fC0iW0g4ZANssSmw4gZA4qYdsyw9tNhWkLmfkj4CkIA4SXgUJRkseBwJU3JMR9SWzQkaaNsUNbIOz6r4lndSQ0LqMsmKUVQSkB7FSZBq5plmi0ho6VM8ZCQoLDx04q0K0ybU4zQcpOnKlG4F0FC"
        },
        function (response) {
            if (response && !response.error) {

                createTable(response, 'page-posts-table');

            }
        }
    );
    
};

});