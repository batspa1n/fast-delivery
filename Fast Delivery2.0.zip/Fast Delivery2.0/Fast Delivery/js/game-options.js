import { initializeApp } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-app.js";
import { getFirestore, collection, doc, addDoc, setDoc } from "https://www.gstatic.com/firebasejs/9.18.0/firebase-firestore.js";


document.addEventListener("DOMContentLoaded", function() {


    // Object to store selected options
    const optionsObject = {};

    // Step form reference
    const stepForm = $('.step-form');

    // Go to next step
    stepForm.on('click', '.card-option', function() {

        // Get current and next step
        const currentStep = stepForm.children('.step.active');
        const nextStep = currentStep.next('.step');

        // Store selected option
        const selectedOption = $(this).find('img').attr('data-option-value');
        const stepName = $(this).find('img').attr('data-option-name');
        optionsObject[`${stepName}`] = selectedOption;

        if(nextStep.length > 0) {
            
            // Change Step

            currentStep.fadeOut(500, function() {
                currentStep.removeClass('active');
                nextStep.addClass('active').fadeIn();
            });
        }
        else {
            // Initialize game

            if(optionsObject['game-mode'] == 'multiplayer') {
                startMultiplayerGame();
            }
            else {
                startSingleplayerGame();
            }

        }

    });

    // Return to previous step
    $('.back-button').on('click', function() {
        
        // Get current and previous step
        const currentStep = stepForm.children('.step.active');
        const prevStep = currentStep.prev('.step');

        // Remove "selected" state
        $(this).blur();

        if(prevStep.length > 0) {

            // Get step name and remove it from options object
            const stepName = $(prevStep).find('img').attr('data-option-name');
            delete optionsObject[`${stepName}`];

            // Change step
            prevStep.fadeOut(500, function() {
                currentStep.removeClass('active');
                prevStep.addClass('active').fadeIn();
            });
        }
        else {

            // Return to main page
            window.location.replace('/');
        }

    });


    function startSingleplayerGame() {

        const selectedCharacter = optionsObject['character'];
        const selectedMap = optionsObject['map'];

        localStorage.setItem("singleplayerCharacter", selectedCharacter);
        localStorage.setItem("difficulty", optionsObject['difficulty']);

        if(selectedMap == "cocina") {
            
            window.location.replace("/singleplayer/UN_Medio.html");
        }
        else if(selectedMap == "restaurante") {

            window.location.replace("/singleplayer/restaurant.html");
        }
        else {
            window.location.replace("/singleplayer/parking.html");
        }

    }

    async function startMultiplayerGame() {
        
        // Your web app's Firebase configuration
        const firebaseConfig = {
            apiKey: "AIzaSyAXVGvvMaGlOgT8xvq10EZ0a2kSPpA1Cho",
            authDomain: "policias-vs-ratones.firebaseapp.com",
            projectId: "policias-vs-ratones",
            storageBucket: "policias-vs-ratones.appspot.com",
            messagingSenderId: "872110097470",
            appId: "1:872110097470:web:ef18ee3aef91342e203d6f"
        };
        
        // Initialize Firebase
        const app = initializeApp(firebaseConfig);

        // Initialize Cloud Firestore and get a reference to the service
        const database = getFirestore(app);


        try {

            const currentUserUid = localStorage.getItem("currentUserUid");
            const currentPlayerName = localStorage.getItem("currentPlayerName");
            const selectedCharacter =  optionsObject['character'];
            
            // Create session documents
            const sessionDocReference = await addDoc(collection(database, "sessions"), {          
                difficulty: optionsObject['difficulty'],
                map: optionsObject['map'],
                active: true,   
                selected_character: selectedCharacter,
                player1_uid: currentUserUid,
                player2_uid: null,
                game_paused: false,
                power_ups: ['cheese-flamin-hot', 'cheese-radiaoactive', 'donut', 'trap'],
                cheeses: ['cheese1', 'cheese2', 'cheese3'],
            });

            // Create players collection
            await setDoc(doc(collection(database, "sessions", sessionDocReference.id, "players"), currentUserUid), {
                character: optionsObject['character'],
                player_name: currentPlayerName,
                player_uid: currentUserUid,
                score: 0,
                position: {
                    x: (selectedCharacter == 'mouse') ? 100.0 : -100.0,
                    z: (selectedCharacter == 'mouse') ? 100.0 : -100.0,
                },
                is_invulnerable: false,
                objectives_count: 0,
                start_game: false,
            });
        
            // Redigir al mapa
            window.location.replace(`multiplayer/lobby.html?id=${sessionDocReference.id}`);

        } catch (e) {

            console.error("Error adding document: ", e);
        }
     
    }



});