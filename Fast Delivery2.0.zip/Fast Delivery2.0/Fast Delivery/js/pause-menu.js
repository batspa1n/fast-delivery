
$('.btn-back').on('click', function() {
        
    window.history.back();

});