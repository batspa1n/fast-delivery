const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Generar enlace de compartición
app.get("/share", (req, res) => {
    const { url, platform, text } = req.query;
    if (!url) return res.status(400).json({ error: "Falta la URL" });

    let shareLink = "";
    switch (platform) {
        case "whatsapp":
            shareLink = `https://api.whatsapp.com/send?text=${encodeURIComponent(text + ' ' + url)}`;
            break;
        case "facebook":
            shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
            break;
        case "twitter":
            shareLink = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
            break;
        case "telegram":
            shareLink = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
            break;
        default:
            return res.status(400).json({ error: "Plataforma no soportada" });
    }

    res.json({ shareLink });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});

